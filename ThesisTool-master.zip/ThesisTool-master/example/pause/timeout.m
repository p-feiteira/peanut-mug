function [] = timeout(timer)

pause (timer);
disp('Done');

end