addpath('F:\Users\pedro\Documents\GitHub\ThesisTool\client\src\main');
% --- Some code ------
for i=1:5
execute(i, @disp, i);
end

result = 0;
for i=1:5
[completedIdx, ftemp] = next();
disp(completedIdx);
disp("ftemp: " + ftemp);
result = result + ftemp;
end
disp(result);

cancel();

% ---- Some code ------