
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Main {

    private static final int THRESHOLD = 100;
    private static BlockingQueue<Integer> queue;

    public static void main(String[] args) {

        queue = new ArrayBlockingQueue<Integer>(THRESHOLD);

        int available = Runtime.getRuntime().availableProcessors();

        System.out.println("Machine with " + available + " available processors, it will be launched " + available*2 + " requests at a time.");

        ExecutorService pool = Executors.newFixedThreadPool(available);

        int interations = 0;
        long start = System.currentTimeMillis();
        while (queue.remainingCapacity() > 0) {
            interations++;
            int counter = 0;
            while (counter < available * 2) {
                pool.submit(() -> {
                    try {
                        Thread.sleep(1000);
                        Random r = new Random();
                        int element = r.nextInt();
                        queue.add(element);
                        System.out.println("Finished! Added " + element + " to the Queue");
                    } catch (InterruptedException e) {
                        System.err.println("Sleep error");
                        System.exit(1);
                    }
                });
                counter++;
            }
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                System.err.println("Sleep error");
                System.exit(1);
            }
        }

        System.out.println("To acheive the size: " + THRESHOLD + " it was needed " + interations
                + " iterations. The execution took " + (System.currentTimeMillis() - start) + " ms");

        pool.shutdown();
        try {
            pool.awaitTermination(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
        }

    }

}