function [x_final,f_final,histout,time] = BoostSID_PSM_parallel(x_initial,const,output,problem)
%
% Purpose:
%
% Function BoostSID_PSM_parallel applies a pattern search method to the problem:
%
%          min f(x)  s.t.  c_i(x) <= 0, i = 1,...,m,
%
% where x is a real vector of dimension n. The derivatives of the function
% f are unknown. Only function values are provided for f. Both function and
% gradient values are provided for c_i, i = 1,...,m. Exploits parallelism at
% the poll step of the algorithm.
%
% The user must provide: problem (for f function values),
%
%                        and, if const = 1,
%
%                        func_const (for c_i, i = 1,...,m, function values),
%                        grad_const (for c_i, i = 1,...,m, gradient values).
%
% Input:
%
%         x_initial (the initial point to start the optimizer).
%
%         const (0-2 variable: 0 if the problem is unconstrained;
%               1 if the problem has general constraints; 2 if the
%               constraints are only bounds).
%
%         output (0-2 variable: 0 - no output; 1 - verbose;
%                2 - very verbose).
%
%		  problem: (name of the problem file; should be in the same
%				   directory as BoostSID_PSM).
%
% Output:
%
%         BoostSID_PSM_report.txt (output text file).
%
% Functions called: domain, eval_point, gen, grad_act, lambda_poised, match_point,
%                   mesh_proc, order_proc, proj_ort, prune_dir, new_quad_Frob,
%                   simplex_deriv (provided by the optimizer).
%
% Further note: The two sections labelled "%%%PARPOOL%%%" can be put outside
% 				the algorithm to save time for multiple runs. The procedure of
%				building a parallel pool is time consuming and this pool only
%				needs to be closed when all tests are finished or when the user
%				wants to try different numbers of processors.

% Copyright (C) 2009 A. L. Custodio and L. N. Vicente.
% http://www.mat.uc.pt/sid-psm
%
% BoostSID_PSM Version 0.2
% Copyright (C) 2020 A. L. Cust�dio, V. Duarte, P. Medeiros, S. Tavares.
% https://docentes.fct.unl.pt/algb/pages/boostdfo
%
% This library is free software; you can redistribute it and/or
% modify it under the terms of the GNU Lesser General Public
% License as published by the Free Software Foundation; either
% version 2.1 of the License, or (at your option) any later version.
%
% This library is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% Lesser General Public License for more details.
%
% You should have received a copy of the GNU Lesser General Public
% License along with this library; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
%
addpath('F:\Users\pedro\Documents\GitHub\ThesisTool\client\src\main');
addpath('./evaluation/SID-PSM/SID-PSM');
time = clock;
warning off all;
format compact;
format long;
fprintf('\n\n');
rand('state', 0);
n = size(x_initial,1);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set tolerances, parameters and constants (not to be user-modified).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
output_file = "BoostSID_PSM_report.txt";
report_size = 100;
histout = zeros(report_size,2);
if output < 2
    REPORT = zeros(3,report_size);
else
    REPORT = zeros(n+8,report_size);
end
%
parameters; % Accept the parameters defined by the user or
            % load the default values.
%
if ~oportunistic
    order_option = 0;
end
%
quad_Function = str2func("new_quad_Frob");
%
tol_degconst = 10^-3;  % Tolerance for degenerated constraints.
tol_hess     = 10^-3;  % Tolerance for degenerated Hessian element.
tol_Delta    = 10^-5;  % Minimum trust-region radius used in model
                       % computation.
%
% For \Lambda-poised set computation.
%
lambda     = 100;       % \Lambda-poised constant.
sigma      = 2;         % Coefficient used in trust-region definition.
tol_degset = sqrt(eps); % Tolerance value for considering a\Lambda-poised
                        % set as degenerated.
%
% For simplex derivatives computation.
%
if shessian
    if store_all
        s_min = 2*n+1;
        s_max = 2*n+1;
        p_max = (n+1)*(n+2);
    else
        s_min = n;
        s_max = 2*n+1;
        p_max = (n+1)*(n+2);
    end
else
    if store_all
        s_min = n+1;
        s_max = n+1;
        p_max = (n+1)*(n+2);
    else
        s_min = floor((n+1)/2);
        s_max = n+1;
        p_max = (n+1)*(n+2);
    end
end
%
% For cache implementation.
%
Cache_infeasible = [];
Cache_normInf = [];
if cache == 1
    n_cache = 50*(n+1);
else
    n_cache = p_max;
end
%
tol_match = 10^-2*tol_alfa; % Tolerance used in point comparisons.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set counters.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
func_eval   = 0; % Function evaluation counter.
iter        = 0; % Iteration counter.
iter_suc    = 0; % Successful iteration counter.
iter_uns    = 0; % Unsuccessful iteration counter.
%
if ordered
    actual_eval = 1; % Function evaluations that actually matter for the results
end					 % obtained (ordered parallel version).
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialization step.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%PARPOOL%%%
%
% Initialize parallel pool.
%
%delete(gcp('nocreate')); % Prevent errors for multiple runs.
%parpool(myCluster,[1,numWorkers]);
%poolobj = gcp('nocreate');
%numWorkers = poolobj.NumWorkers;
%
%%%PARPOOL%%%
%
% Compute a set of positive generators at the initial point.
%
% For the unconstrained case.
%
if ~const
    [D,~] = gen(pss,n,const);
    r       = -1;
else
%
% For the constrained case.
%
% Check whether the initial point is feasible or not.
%
    [feasible,c_const] = domain(x_initial);
    if ~feasible
        fprintf('Initial point provided is not feasible. \n\n');
        fprintf('Please call function BoostSID_PSM_parallel with a feasible point. \n\n\n');
        return
    end
%
    epsilon = epsilon_ini;
    [r,A]   = grad_act(x_initial,c_const,epsilon);
    if (const == 2) && (~pss || pss == 3)
        fprintf('For bound constrained optimization, the positive generating set ')
        fprintf('considered should include the coordinate directions. \n\n');
        fprintf('Please call function BoostSID_PSM_parallel with a different positive spanning set. \n\n\n');
        return
    end
    [D,deg] = gen(pss,n,const,r,A,tol_degconst);
    if deg
        print_format = 'Degenerated situation encountered. r = %2d. \n\n\n';
        fprintf(print_format, r);
        return
    end
end
%
% Determine the number of positive generators.
%
nD    = size(D,2);
max_D = max(sqrt(sum(D.^2)));
%
% Compute f at the initial point.
%
x         = x_initial;
f_eval    = str2func(problem);
f         = f_eval(x);
func_eval = func_eval+1;
%
% Record the initial point for printing.
%
histout(iter+1,1) = 1;
histout(iter+1,2) = f;
if (output < 2)
    REPORT(1,1) = 0;
    REPORT(2,1) = f;
    REPORT(3,1) = alfa;
else
    REPORT(1,1)     = 0;
    REPORT(2,1)     = -1;
    REPORT(3,1)     = -1;
    REPORT(4:n+3,1) = x;
    REPORT(n+4,1)   = f;
    REPORT(n+5,1)   = alfa;
    REPORT(n+6,1)   = r;
    REPORT(n+7,1)   = -1;
    REPORT(n+8,1)   = -1;
end
%
% Initialize the cache and/or the list used in simplex derivatives computation.
%
CacheP(:,1)      = x;
CacheF(1) = f;
CachenormP(1) = norm(x,1);
if cache == 1
    label(1) = 1;
end
%
% Print the iteration report header.
%
if (output > 0)
    fprintf('Iteration Report: \n\n');
    if (output == 1)
        fprintf('| iter  |     f_value     |      alpha      |\n');
        print_format = '| %5d | %+13.8e | %+13.8e |\n';
        fprintf(print_format, iter, f, alfa);
    else
        fprintf('| iter  | success | #fevals |     f_value     |');
        fprintf('      alpha      | active | search | poised |\n');
        print_format = '| %5d |    %2s   |    %2s   | %+13.8e | %+13.8e |';
        if r == -1
            print_format = strcat(print_format,'   %2s   |   %2s   |   %2s   |\n');
            fprintf(print_format, iter, '--', '--', f, alfa, '--', '--', '--');
        else
            print_format = strcat(print_format,'   %2d   |   %2s   |   %2s   |\n');
            fprintf(print_format, iter, '--', '--', f, alfa, r, '--', '--');
        end
    end
end
%
% Initialize some auxiliary variables.
%
halt         = 0;
poised       = -1;
search_step  = -1;
quad         = 0;
col_index    = 1;
deriv_old    = zeros(n,1);
max_D_old    = max_D;
if order_option == 2
    first_flag_colD = 0;
end
if mesh_option == 3
    dir_past = zeros(n,1);
end
%
% Initialize some auxiliary variables used in model computation.
%
if search_option && always
    H_old  = zeros(n);
    g_old  = zeros(n,1);
    H_calc = 0;
end
if const && (order_option == 2)
    max_nD = nD+1;
else
    max_nD = nD;
end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% START THE PATTERN SEARCH METHOD.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
while (~halt)
    success          = 0;
    func_iter        = 0;
    func_iter_finite = 0;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SEARCH STEP.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
    match = 0;
    
    if search_option
        search_step = 0;
%
% Compute the quadratic model.
%
        Delta = alfa * sigma * max_D_old;
        if Delta < tol_Delta
            Delta = tol_Delta;
        end
        if Delta > tol_match
            if cache == 1
                X_aux        = CacheP(:,label == 1);
                X_aux        = X_aux(:,1:min(size(X_aux,2),p_max));
                F_values_aux = CacheF(label == 1);
                F_values_aux = F_values_aux(:,1:size(X_aux,2));
                [quad,H,g] = quad_Function(X_aux,F_values_aux,always,regopt,H_calc);
            else
                [quad,H,g] = quad_Function(CacheP,CacheF,always,regopt,H_calc);
            end
            %
            % If a quadratic model exists, compute a trust region trial point.
            %
            if quad
                if quad == 1
                    H_old  = H;
                    g_old  = g;
                    H_calc = H_calc + 1;
                else
                    H = H_old;
                    g = g_old;
                end
                if norm(g) <= eps
                    info       = 1;
                    [U,e]      = eig(H);
                    [~,indexe] = sort(diag(e));
                    xtemp      = Delta* U(:,indexe(1))/norm(U(:,indexe(1)));
                else
                    if trs_solver
                        [~,xtemp,~,info] = soltr(H,g,Delta);
                    else
                        info    = 1;
                        [xtemp] = trust(g,H,Delta);
                    end
                end
                if info >= 0
                    xtemp = xtemp + x;
%
% Check whether the trial point is feasible or not.
%
                    if const
                        [feasible,~] = domain(xtemp);
                    end
%
% In case of bound constrained optimization, project the trial point into
% the feasible region.
%
                    if (const == 2) && ~feasible
                        [xtemp,feasible] = proj_ort(xtemp);
                    end
%
% Compute the function value at the point or find a match.
%
                    if ~const || feasible
                        if cache
                            xtempnorm           = norm(xtemp,1);
                            match = match_point(xtemp,xtempnorm,CacheP,...
                                CachenormP,Cache_infeasible,Cache_normInf,tol_match);
                        end
                        if ~match
                            ftemp     = f_eval(xtemp);
                            func_eval = func_eval + 1;
                            func_iter = func_iter + 1;
                            if ordered
                                actual_eval = actual_eval + 1;
                            end
%
% Test for a better function value.
%
                            if isfinite(ftemp)
                                if ftemp < f
                                    success     = 1;
                                    search_step = 1;
                                end           
%
% Update the cache and/or the list used in simplex derivatives
% computation (store_all version).
%
                                if (store_all && (search_option || (order_option == 1) ||...
                                        (order_option == 5) || stop_grad || (mesh_option == 1) ||...
                                        (mesh_option == 2) || (cache == 2))) || (cache == 1)
                                    colX = size(CacheP,2);
                                    if cache == 1
                                        if store_all
                                            label = [1,label(:,1:min(n_cache-1,colX))];
                                        else
                                            label = [0,label(:,1:min(n_cache-1,colX))];
                                        end
                                    end
                                    func_iter_finite = func_iter_finite + 1;
                                    CacheP        = [xtemp,CacheP(:,1:min(n_cache-1,colX))];
                                    CacheF = [ftemp,CacheF(:,1:min(n_cache-1,colX))];
                                    if cache
                                        CachenormP = [xtempnorm,CachenormP(:,1:min(n_cache-1,colX))];
                                    end
                                end
                            elseif cache == 1
                                Cache_infeasible = [Cache_infeasible xtemp];
                                Cache_normInf = [Cache_normInf xtempnorm];
                            end
                        end
                    end
                end
            end
        end
    end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% POLL STEP.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
    if search_step ~= 1
        count_col = 0;
        if ((order_option ~= 4) && (order_option ~= 5) && (order_option ~= 8) &&...
                (order_option ~= 9)) || const
            col_index = 1;
        else
            if col_index == nD+1
                col_index = 1;
            end
        end
        if const && (order_option == 2) && ~first_flag_colD
            count_col = 1;
        end      
%
% Permute the set of positive generators.
%
        if order_option == 3
            D = D(:,randperm(nD));
        end
%
% Initialize structures to gather results (iteration independent).
%
        offset = 1;
        if count_col
            offset = 0;
        end
        x_mat = zeros(n, max_nD);
        norm_vector = zeros(1, max_nD);
        init_mask = zeros(1, max_nD);
        if oportunistic
            indexes = zeros(1, max_nD);
        end 
%
% Compute the set of points to evaluate.
%
        while count_col < max_nD
            match  = 0;
%
% Test the last successful direction (dynamic polling option).
%
            if (order_option == 2) && first_flag_colD
                if ~count_col
                    colD      = flag_colD;
                    col_index = 0;
                else
                    colD = D(1:n,col_index);
                    if colD == flag_colD
                        if const
                            count_col = count_col+1;
                            if col_index == nD
                                break
                            end
                        end
                        col_index = col_index + 1;
                        colD      = D(1:n,col_index);
                    end
                end
            else
                colD = D(1:n,col_index);
            end
            xtemp = x + alfa*colD;
%
% Check whether the trial point is feasible or not.
%
            if const
                [feasible,~] = domain(xtemp);
            end
%
% Compute the function value at the point or find a match.
%
            if (~const) || feasible
                xtempnorm = norm(xtemp,1);
                if cache
                    match = match_point(xtemp,xtempnorm,CacheP,...
                        CachenormP,Cache_infeasible,Cache_normInf,tol_match);
                end
%
% Discard matches as they guarantee worse points.
%
                if ~match
                    x_mat(:, count_col + offset) = xtemp;
                    init_mask(count_col + offset) = 1;
                    norm_vector(count_col + offset) = xtempnorm;
                    indexes(count_col + offset) = col_index;
                end
            end
            col_index = col_index + 1;
            if (col_index == nD+1)
                col_index = 1;
            end
            count_col = count_col + 1;
        end     
%
% Crop arrays to get useful points only.
%        
        pointsToEval = sum(init_mask);
        if pointsToEval
            init_mask = logical(init_mask);
            x_mat = x_mat(:,init_mask);
            norm_vector = norm_vector(init_mask);
            
            if oportunistic
                indexes = indexes(init_mask);
                rotation_vec = zeros(1, pointsToEval);
            end
            
            f_vector = zeros(1, pointsToEval);
            mask_f = zeros(1, pointsToEval);
%
% Parallel evaluation of candidates (oportunistic).
%
            if oportunistic
                for ii = 1:pointsToEval
                    %futures(ii) = parfeval(@eval_point, 1, x_mat(:,ii), f_eval);
                    execute(ii, @eval_point, x_mat(:,ii), f_eval);
                end
%
% Gather iteration results.
%
                if ordered % Force ordering on reception.
                    lastIndex = 0;
                    results(pointsToEval) = 0;
                    mask_res = zeros(pointsToEval,1);
                    endcycle = 0;
                    for jj = 1:pointsToEval
                        %[completedIdx,ftemp] = fetchNext(futures);
                        [completedIdx, ftemp] = next();
                        func_eval = func_eval + 1;
                        func_iter = func_iter + 1;
                        results(completedIdx) = ftemp;
                        mask_res(completedIdx) = 1;
                        while completedIdx == (lastIndex+1)
                            actual_eval = actual_eval + 1;
                            if isfinite(ftemp)
                                f_vector(pointsToEval - completedIdx + 1) = ftemp;
                                rotation_vec(pointsToEval - completedIdx + 1) = completedIdx;
                                mask_f(pointsToEval - completedIdx + 1) = 1;
                                if ftemp < f
                                    success = 1;
                                    xtemp = x_mat(:,completedIdx);
                                    xtempnorm = norm_vector(completedIdx);
                                    if order_option == 2
                                        tmpindex = indexes(completedIdx);
                                        if tmpindex % In case its 0, remains the same.
                                            first_flag_colD = 1;
                                            flag_colD = D(1:n, tmpindex);
                                        end
                                    end
                                    endcycle = 1;
                                    break;
                                end
                            elseif cache == 1
                                Cache_infeasible = [Cache_infeasible x_mat(:,completedIdx)];
                                Cache_normInf = [Cache_normInf norm_vector(completedIdx)];
                            end
                            lastIndex = lastIndex+1;
                            if completedIdx < pointsToEval && mask_res(completedIdx+1)
                                completedIdx = completedIdx+1;
                                ftemp = results(completedIdx);
                            end
                        end
                        if endcycle
                            break;
                        end
                    end
                else % Regular paralellism.
                    for jj = pointsToEval:-1:1
                        %[completedIdx,ftemp] = fetchNext(futures);
                        [completedIdx, ftemp] = next();
                        func_eval = func_eval + 1;
                        func_iter = func_iter + 1;
                        if isfinite(ftemp)
                            f_vector(jj) = ftemp;
                            rotation_vec(jj) = completedIdx;
                            mask_f(jj) = 1;
                            if ftemp < f
                                success = 1;
                                xtemp = x_mat(:,completedIdx);
                                xtempnorm = norm_vector(completedIdx);
                                if order_option == 2
                                    tmpindex = indexes(completedIdx);
                                    if tmpindex % In case its 0, remains the same.
                                        first_flag_colD = 1;
                                        flag_colD = D(1:n, tmpindex);
                                    end
                                end
                                break;
                            end
                        elseif cache == 1
                            Cache_infeasible = [Cache_infeasible x_mat(:,completedIdx)];
                            Cache_normInf = [Cache_normInf norm_vector(completedIdx)];
                        end
                    end
                end
                cancel();
                %cancel(futures);
                %futures(1:pointsToEval) = []; 
%
% Order results (for cache insertion).
%
                numToUpdate = sum(mask_f);
                if numToUpdate
                    mask_f = logical(mask_f);
                    f_vector = f_vector(mask_f);
                    rotation_vec = rotation_vec(mask_f);
                    x_mat = x_mat(:,rotation_vec);
                    norm_vector = norm_vector(rotation_vec);
                end 
%
% Complete evaluation of candidates (also parallel).
%
            else
                %parfor (ii = 1:pointsToEval, numWorkers)
                    %f_vector(ii) = f_eval(x_mat(:,ii));
                %end
                for ii=1:pointsToEval
                    execute(ii, f_eval, x_mat(:,ii));
                end
                for ii=1:pointsToEval
                    [idx, ftemp] = next();
                    f_vector(ii) = ftemp;
                end
                cancel();
                func_eval = func_eval + pointsToEval;
                func_iter = func_iter + pointsToEval;
%
% Test for finite values and update infeasible cache.
%
                mask_f = isfinite(f_vector);
                if cache == 1
                    inf_points = x_mat(:,~mask_f);
                    inf_norms = norm_vector(~mask_f);
                    Cache_infeasible = [Cache_infeasible inf_points];
                    Cache_normInf = [Cache_normInf inf_norms];
                end
%
% Evaluate success and prepare storing.
%
                numToUpdate = sum(mask_f);
                if numToUpdate
                    f_vector = f_vector(mask_f);
                    x_mat = x_mat(:,mask_f);
                    norm_vector = norm_vector(mask_f);
                    [m, i] = min(f_vector);
                    ftemp = m;
                    xtemp = x_mat(:,i);
                    xtempnorm = norm_vector(i);
                    max_size = size(f_vector,2);
                    if ftemp < f
                        success = 1;
                        aux_rot = [i 1:i-1 i+1:max_size];
                        f_vector = f_vector(aux_rot);
                        x_mat = x_mat(:,aux_rot);
                        norm_vector = norm_vector(aux_rot);
                    end
                end
            end
        else
            numToUpdate = 0;
        end
%
% Update the cache and/or the list of points used in simplex
% derivatives computation (store_all version).
%
        if numToUpdate && ((store_all && (search_option || (order_option == 1) ||...
                (order_option == 5) || stop_grad || (mesh_option == 1) ||...
                (mesh_option == 2) || (cache == 2))) || (cache == 1))
            colX = size(CacheP,2);
            if cache == 1
                if store_all
                    label = [ones(1,numToUpdate),label(:,1:min(n_cache-numToUpdate,colX))];
                else
                    label = [zeros(1,numToUpdate),label(:,1:min(n_cache-numToUpdate,colX))];
                end
            end
            func_iter_finite = func_iter_finite + numToUpdate;
            CacheP          = [x_mat,CacheP(:,1:min(n_cache-numToUpdate,colX))];
            CacheF   = [f_vector,CacheF(:,1:min(n_cache-numToUpdate,colX))];
            if cache
                CachenormP = [norm_vector,CachenormP(:,1:min(n_cache-numToUpdate,colX))];
            end
        end
    end
    iter = iter + 1;
%
% Update the mesh size parameter.
%
    match_dir = 0;
    if mesh_option == 3
        if success
            dir_new = (xtemp-x) / alfa;
            if (dir_past == dir_new)
                match_dir = 1;
            end
            dir_past = dir_new;
        else
            dir_past = zeros(n,1);
        end
    end
    if ~mesh_option || (mesh_option == 3)
        alfa = mesh_proc(alfa,mesh_option,success,phi,theta,match_dir);
    else
        if poised == 2
            alfa = mesh_proc(alfa,mesh_option,success,phi,theta,match_dir,...
                poised,x,xtemp,f,ftemp,g,H);
        elseif poised == 1
            alfa = mesh_proc(alfa,mesh_option,success,phi,theta,match_dir,...
                poised,x,xtemp,f,ftemp,g);
        else
            alfa = mesh_proc(alfa,mesh_option,success,phi,theta,match_dir,poised);
        end
    end
%
    if success
        iter_suc = iter_suc + 1;
%
% Update the cache and/or the list of points used in simplex
% derivatives computation (store-successful version).
%
        if ~store_all && (search_option || (order_option == 1) || (order_option == 5) ||...
                stop_grad || (mesh_option == 1) || (mesh_option == 2) ||...
                cache)
            if cache == 1
                label(1) = 1;
            else
                colX     = size(CacheP,2);
                CacheP        = [xtemp,CacheP(:,1:min(n_cache-1,colX))];
                CacheF = [ftemp,CacheF(:,1:min(n_cache-1,colX))];
                if cache
                    CachenormP = [xtempnorm,CachenormP(:,1:min(n_cache-1,colX))];
                end
            end
        end
        f = ftemp;
        x = xtemp;
%        
% Reorder column index (one after success).
%
        if oportunistic && search_step ~= 1
            indx = find(init_mask);
            col_index = col_index + indx(rotation_vec(1));
            if(col_index > max_nD)
                col_index = col_index - max_nD;
            end
        end
    else
        iter_uns = iter_uns + 1;
    end
%  
    if iter == size(histout,1)
        prevsize = size(histout,1);
        histaux = zeros(prevsize+report_size,2);
        histaux(1:prevsize,:) = histout;
        histout = histaux;
        if output < 2
            repaux = zeros(3,prevsize+report_size);
            repaux(:,1:prevsize) = REPORT;
            REPORT = repaux;
        else
            repaux = zeros(n+8,prevsize+report_size);
            repaux(:,1:prevsize) = REPORT;
            REPORT = repaux;
        end
    end
%
% Record the iteration results for printing.
%
    histout(iter+1,1) = histout(iter,1) + func_iter;
    histout(iter+1,2) = f;
    if (output < 2)
        REPORT(1,iter+1)     = iter;
        REPORT(2,iter+1)     = f;
        REPORT(3,iter+1)     = alfa;
    else
        REPORT(1,iter+1)     = iter;
        REPORT(2,iter+1)     = success;
        REPORT(3,iter+1)     = func_iter;
        REPORT(4:n+3,iter+1) = x;
        REPORT(n+4,iter+1)   = f;
        REPORT(n+5,iter+1)   = alfa;
        REPORT(n+6,iter+1)   = r;
        REPORT(n+7,iter+1)   = search_step;
        REPORT(n+8,iter+1)   = -1;
    end
    max_D_old = max_D;
%
% If in the constrained case, compute a set of positive
% generators at the new point.
%
    if const
        [~,c_const] = domain(x);
        epsilon  = min(epsilon_ini,10*alfa);
        [r,A]    = grad_act(x,c_const,epsilon);
        [D,deg]  = gen(pss,n,const,r,A,tol_degconst);
        nD       = size(D,2);
        max_D    = max(sqrt(sum(D.^2)));
        if deg
            print_format = 'Degenerated situation encountered. r = %2d. \n\n\n';
            fprintf(print_format, r);
            return
        end
    end
%
% If in the unconstrained case and pruning was selected, compute a set of
% positive generators at the new point.
%
    if ~const && pruning
        [D,~]  = gen(pss,n,const);
        nD       = size(D,2);
        max_D    = max(sqrt(sum(D.^2)));
    end
%
% Move the last successful iterate for the first column of
% the matrix used in simplex derivatives computation.
%
    if  store_all && ~success && (search_option || (order_option == 1) || (order_option == 5) || stop_grad ||...
            (mesh_option == 1) || (mesh_option == 2))
        aux_x                          = CacheP(:,func_iter_finite+1);
        CacheP(:,2:func_iter_finite+1)      = CacheP(:,1:func_iter_finite);
        CacheP(:,1)                         = aux_x;
        aux_f                          = CacheF(func_iter_finite+1);
        CacheF(2:func_iter_finite+1) = CacheF(1:func_iter_finite);
        CacheF(1)                    = aux_f;
        if cache
            aux_n                         = CachenormP(func_iter_finite+1);
            CachenormP(2:func_iter_finite+1) = CachenormP(1:func_iter_finite);
            CachenormP(1)                    = aux_n;
        end
        if cache == 1
            aux_l                       = label(func_iter_finite+1);
            label(2:func_iter_finite+1) = label(1:func_iter_finite);
            label(1)                    = aux_l;
        end
    end
    if (order_option == 1) || (order_option == 5) || stop_grad ||...
            (mesh_option == 1) || (mesh_option == 2)
%
% Try to build a \Lambda-poised set.
%
        Delta = sigma * alfa * max_D_old;
        if cache == 1
            X_aux        = CacheP(:,label == 1);
            X_aux        = X_aux(:,1:min(size(X_aux,2),p_max));
            F_values_aux = CacheF(label == 1);
            F_values_aux = F_values_aux(:,1:size(X_aux,2));
            [poised,Y,Y_values] = lambda_poised(X_aux,F_values_aux,s_min,...
                s_max,Delta,lambda,tol_degset,shessian,economic);
        else
            [poised,Y,Y_values] = lambda_poised(CacheP,CacheF,s_min,...
                s_max,Delta,lambda,tol_degset,shessian,economic);
        end
%
        if (output == 2)
            REPORT(n+8,iter+1) = poised;
        end
%
% Compute the simplex derivatives.
%
        if poised
            deriv = simplex_deriv(Y,Y_values',poised,min_norm,deriv_old);
            if ~min_norm
                deriv_old = deriv;
            end
            g = deriv(1:n);
            if poised == 2
                aux_hess        = deriv(n+1:2*n);
                logic           = logical(abs(aux_hess)<tol_hess);
                aux_hess(logic) = aux_hess(logic)+sign(aux_hess(logic))*tol_hess;
                logic           = logical(~aux_hess);
                aux_hess(logic) = aux_hess(logic) + tol_hess;
                H               = diag(aux_hess);
            end
%
% Compute the descent indicator to be used in the search step and/or for
% reordering the polling vectors.
%
            if (order_option == 1) || (order_option == 5)
                if poised == 2
                    di = -diag(1./diag(H))*g;
                else
                    di = -g;
                end
%
% Reorder the vectors in the positive generator set using the
% descent indicator and prunes the positive generator set.
%
                [D,di_cosines] = order_proc(D,di);
                col_index      = 1;
                if pruning
                    D  = prune_dir(D,di_cosines,pruning);
                    nD = size(D,2);
                end
            end
%
% Build a stopping indicator based on simplex gradients.
%
            if stop_grad == 2
                nsimp        = size(Y,2);
                dir          = Y(:,2:nsimp) - diag(Y(:,1))*ones(n,nsimp-1);
                sg_dir_deriv = dir'*g;
                if sg_dir_deriv >= -tol_grad
                    halt = 1;
                end
            else
                if (stop_grad == 1) && (max(abs(Delta*g)) <= tol_grad)
                    halt = 1;
                end
            end
        end
    end
    if ((order_option == 6) || (order_option == 8)) && quad
        if shessian
            di = -H_old*g_old;
        else
            di = -g_old;
        end
        D       = order_proc(D,di);
        col_index = 1;
    end 
%
% Reorder the vectors in the positive generator set according to the
% model values.
%
    if ((order_option == 7) || (order_option == 9)) && quad
        xvec = diag(x)*ones(n,nD) + alfa*D;
        for j = nD:-1:1
            fvec(1,j) = g_old'*xvec(:,j) + xvec(:,j)'*H_old*xvec(:,j)/2;
        end
        [~,ind] = sort(fvec);
        D          = D(:,ind);
        col_index  = 1;
    end
%
% Test for ending.
%
    if (stop_alfa && (alfa < tol_alfa))
        halt = 1;
    end
    if (stop_fevals && (func_eval >= fevals_max))
        halt = 1;
    end
    if (stop_iter && (iter >= iter_max))
        halt = 1;
    end
%
% Print iteration report.
%
    if (output > 0)
        if (output == 1)
            print_format = '| %5d | %+13.8e | %+13.8e |\n';
            fprintf(print_format, iter, f, alfa);
        else
            print_format = '| %5d |    %2d   |    %2d   | %+13.8e | %+13.8e |';
            if r == -1
                if poised == -1
                    if search_step == -1
                        print_format = strcat(print_format,'   %2s   |   %2s   |   %2s   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, '--', '--', '--');
                    else
                        print_format = strcat(print_format,'   %2s   |   %2d   |   %2s   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, '--', search_step, '--');
                    end
                else
                    if search_step == -1
                        print_format = strcat(print_format,'   %2s   |   %2s   |   %2d   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, '--' ,'--', poised);
                    else
                        print_format = strcat(print_format,'   %2s   |   %2d   |   %2d   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, '--' ,search_step, poised);
                    end
                end
            else
                if poised == -1
                    if search_step == -1
                        print_format = strcat(print_format,'   %2d   |   %2s   |   %2s   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, r, '--', '--');
                    else
                        print_format = strcat(print_format,'   %2d   |   %2d   |   %2s   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, r, search_step, '--');
                    end
                else
                    if search_step == -1
                        print_format = strcat(print_format,'   %2d   |   %2s   |   %2d   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, r ,'--', poised);
                    else
                        print_format = strcat(print_format,'   %2d   |   %2d   |   %2d   |\n');
                        fprintf(print_format, iter, success, func_iter, f, alfa, r ,search_step, poised);
                    end
                end
            end
        end
    end   
end 
%
time    = etime(clock,time);
x_final = x;
f_final = f;
%
%%%PARPOOL%%%
%
%delete(gcp('nocreate'));
%
%%%PARPOOL%%%
%
histout = histout(1:iter+1,:);
REPORT = REPORT (:,1:iter+1);
%
% Print final report.
%
if (output~=0)
    fprintf('\n\nFinal Report: \n\n');
    print_format = 'Elapsed Time = %10.3e \n\n';
    fprintf(print_format,time);
    fprintf('| #iter | #isuc | #fevals |  final f_value  |   final alpha   |\n');
    print_format = '| %5d | %5d |  %5d  | %+13.8e | %+13.8e |\n\n';
    fprintf(print_format, iter, iter_suc, func_eval, f, alfa);
    fprintf('Minimum Point:\n');
    for i = 1:n
        fprintf('%13.8e \n',x(i));
    end
%
% Print report file.
%
    fresult = fopen(output_file,'w');
    fprintf(fresult,'Report: \n\n');
    if (output == 1)
        fprintf(fresult,'| iter  |     f_value     |      alpha      |\n');
        print_format  = '| %5d | %+13.8e | %+13.8e |\n';
        fprintf(fresult,print_format,REPORT(:,1:iter+1));
    else
        print_format   = '| iter  | success | #fevals |';
        string_counter = 1;
        for i = 1:n
            if fix(i/10^string_counter) == 1
                string_counter = string_counter + 1;
            end
            print_format = strcat(print_format,'      x(',int2str(i),')');
            for j = 1:(8-string_counter)
                print_format = strcat(print_format,char(160));
            end
            print_format = strcat(print_format,'|');
        end
        print_format = strcat(print_format,'     f_value     |      alpha      |');
        print_format = strcat(print_format,' active | search | poised |\n');
        fprintf(fresult,print_format);
        print_format  = '| %5d |    %2d   |    %2d   |';
        print_format1 = '| %5d |    %2s   |    %2s   |';
        for i = 1:n+2
            print_format  = strcat(print_format,' %+13.8e |');
            print_format1 = strcat(print_format1,' %+13.8e |');
        end
        if r == -1
            print_format1 = strcat(print_format1,'   %2s   |   %2s   |   %2s   |\n');
            if poised == -1
                if search_step == -1
                    print_format  = strcat(print_format,'   %2s   |   %2s   |   %2s   |\n');
                else
                    print_format  = strcat(print_format,'   %2s   |   %2d   |   %2s   |\n');
                end
            else
                if search_step == -1
                    print_format  = strcat(print_format,'   %2s   |   %2s   |   %2d   |\n');
                else
                    print_format  = strcat(print_format,'   %2s   |   %2d   |   %2d   |\n');
                end
            end
        else
            print_format1 = strcat(print_format1,'   %2d   |   %2s   |   %2s   |\n');
            if poised == -1
                if search_step == -1
                    print_format  = strcat(print_format,'   %2d   |   %2s   |   %2s   |\n');
                else
                    print_format  = strcat(print_format,'   %2d   |   %2d   |   %2s   |\n');
                end
            else
                if search_step == -1
                    print_format  = strcat(print_format,'   %2d   |   %2s   |   %2d   |\n');
                else
                    print_format  = strcat(print_format,'   %2d   |   %2d   |   %2d   |\n');
                end
            end
        end
        if r == -1
            fprintf(fresult,print_format1,REPORT(1,1),'--','--',...
                REPORT(4:n+5,1),'--','--','--');
            if poised == -1
                if search_step == -1
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+5,l),'--','--','--');
                    end
                else
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+5,l),'--',REPORT(n+7,l),'--');
                    end
                end
            else
                if search_step == -1
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+5,l),'--','--',REPORT(n+8,l));
                    end
                else
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+5,l),'--',REPORT(n+7,l),REPORT(n+8,l));
                    end
                end
            end
        else
            fprintf(fresult,print_format1,REPORT(1,1),'--','--',...
                REPORT(4:n+6,1),'--','--');
            if poised == -1
                if search_step == -1
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+6,l),'--','--');
                    end
                else
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+7,l),'--');
                    end
                end
            else
                if search_step == -1
                    for l = 2:iter+1
                        fprintf(fresult,print_format,REPORT(1:n+6,l),'--',REPORT(n+8,l));
                    end
                else
                    fprintf(fresult,print_format,REPORT(:,2:iter+1));
                end
            end
        end
    end
    fprintf(fresult,'\n\nFinal Report: \n\n');
    print_format = 'Elapsed Time = %10.3e \n\n';
    fprintf(fresult,print_format,time);
    fprintf(fresult,'| #iter | #isuc | #fevals |  final f_value  |');
    fprintf(fresult,'   final alpha   |\n');
    print_format = '| %5d | %5d |  %5d  | %+13.8e | %+13.8e |\n\n';
    fprintf(fresult,print_format, iter, iter_suc, func_eval, f, alfa);
    fprintf(fresult,'Minimum Point:\n');
    for i = 1:n
        fprintf(fresult,'%13.8e \n',x(i));
    end
    fclose(fresult);
end
%
% End of BoostSID_PSM_parallel.