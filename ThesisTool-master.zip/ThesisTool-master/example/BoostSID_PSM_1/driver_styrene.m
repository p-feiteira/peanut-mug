run("styrene_init");
BoostSID_PSM(x_initial,0,1,'styrene');