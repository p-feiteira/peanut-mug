function evaluation(proxy_node, pid, service_node, dockerid, threads)

addpath('F:\Users\pedro\Documents\GitHub\ThesisTool\example\BoostSID_PSM_1\evaluation\SID-PSM\SID-PSM-init');

dimensions = [5 10 20 30];
%workers = [1 2 4 8 16];

problems = {'activefaces', 'arwhead', 'bdqrtic', 'bdvalue' ,'bertsekas'};

%problems = {'bdvalue'};

filename = 'results_remote.csv';
print_format = '%s,%d,%10.3e\n';
msg_format = 'Evaluating problem %s with dimension %d. Started at %d/%d %d:%d\n';
fresult = fopen(filename,'w');

fprintf(fresult, "problem,dimension,evaltime\n");

const = 0;
output = 1;

%for w = 1:length(workers)

    %wrks = workers(w);

    %fp = fopen('..\\hosts.txt', 'w');

    %fprintf(fp, "node%d:10000:%d",service_node,wrks);

    %fclose(fp);

    %cmd = sprintf("..\\init\\docker\\launch.exe %s", proxy_node);
    %system(cmd);

    %for ii = 1:length(dimensions)

        %dim = dimensions(ii);
        %def = ones(dim,1);

        %x_initial = {def, 1/sqrt(dim) * def};
        %x_initial = [1:dim]';

        for jj = 1:length(problems)
            init = strcat(problems{jj},'_init.m');
            run(init);
            c = clock;
            msg = fprintf(msg_format, problems{jj}, dim, c(3),c(2),c(4),c(5));
            id = tic;
            BoostSID_PSM_parallel(x_initial,const,output,problems{jj});
            elapsed_time = toc(id);
            fprintf(fresult, print_format, problems{jj}, dim, elapsed_time);                 
        end
    %end
    %cmd = sprintf("rm ..\\client\\src\\main\\remote\\currentProj.txt && ssh -p 12034 p.feiteira@cluster.di.fct.unl.pt "ssh %s 'kill %d' && ssh %s 'docker container rm -f %s'",proxy_node, pid, service_node, dockerid);
    %system(cmd);
    if pid ~= -1
        cmd = sprintf(".\\evaluation\\download_eval.bat %s %d %s %s %d",
        proxy_node, pid, service_node, dockerid,threads);
        system(cmd);
    end
%end
fclose(fresult);
end 