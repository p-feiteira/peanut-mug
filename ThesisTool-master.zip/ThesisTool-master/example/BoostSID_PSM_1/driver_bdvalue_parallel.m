addpath('/home/ThesisTool/example/BoostSID_PSM_1/evaluation/SID-PSM/SID-PSM');
addpath('/home/ThesisTool/example/BoostSID_PSM_1/evaluation/SID-PSM/SID-PSM-init');
run("bdvalue_init");
BoostSID_PSM_parallel(x_initial,0,1,'bdvalue');