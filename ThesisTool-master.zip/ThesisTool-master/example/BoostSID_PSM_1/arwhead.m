function [f] = arwhead(x)
%
% Purpose:
%
%    Function arwhead is the Test Problem 55 in the 
%    Appendix of Conn et al (1994) and computes
%    the value of the objective function arwhead.
%
%    dim >= 2
%    Minimum value: 0
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% BoostSID_PSM Version 0.1
% Copyright (C) 2020 A. L. Cust�dio, V. Duarte, P. Medeiros, S. Tavares.
% https://docentes.fct.unl.pt/algb/pages/boostdfo
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This library is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% Lesser General Public License for more details.
%
% You should have received a copy of the GNU Lesser General Public
% License along with this library; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA,
% or see <https://www.gnu.org/licenses/>.
%
dim = length(x);
A   = (x.^2 + x(dim,1)^2).^2 - 4*x+3;
f   = sum(A) - A(dim,1);
%
% End of arwhead.
