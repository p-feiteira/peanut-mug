run("styrene_init");
BoostSID_PSM_parallel(x_initial,0,1,'styrene'); 