% driver_unconst_parallel.m script file
%
% Purpose:
%
% File driver_unconst_parallel applies the parallel version of BoostSID_PSM 
% algorithmic framework to solve the unconstrained optimization problem:
%
%        min sum(A) - A(dim,1),
%
% with   A = (x.^2 + x(dim,1)^2).^2 - 4*x+3
%
% The initial point considered is [1:dim]'. The optimizer uses the
% default options specified in the file parameters.m. A short output
% report is produced, both at the screen and in the text file
% sid_psm_report.txt (stored at the current directory).
%
% BoostSID_PSM Version 0.1
% Copyright (C) 2020 A. L. Cust�dio, V. Duarte, P. Medeiros, S. Tavares.
% https://docentes.fct.unl.pt/algb/pages/boostdfo
%
% This library is free software; you can redistribute it and/or
% modify it under the terms of the GNU Lesser General Public
% License as published by the Free Software Foundation; either
% version 2.1 of the License, or (at your option) any later version.
%
% This library is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
% Lesser General Public License for more details.
%
% You should have received a copy of the GNU Lesser General Public
% License along with this library; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
%
run("arwhead_init");
BoostSID_PSM_parallel(x_initial,0,1,'arwhead');
%
% End of driver_unconst_parallel.