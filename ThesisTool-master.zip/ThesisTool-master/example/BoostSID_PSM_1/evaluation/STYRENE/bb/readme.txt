+ compile with "make"
+ execute with "./truth.exe ./points/x0.txt"

+ the 11 first outputs are constraints with format <= 0
+ the last output is the objective to minimize

+ the bounds are [0;100]

+ results can vary depending on the machine.

+ Best solution has been found by Mathieu Tanneau (2015-11-29).