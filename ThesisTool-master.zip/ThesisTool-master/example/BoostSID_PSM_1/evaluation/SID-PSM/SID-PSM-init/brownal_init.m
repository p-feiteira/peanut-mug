dim = 30;
x_initial = 0.5*ones(dim,1);