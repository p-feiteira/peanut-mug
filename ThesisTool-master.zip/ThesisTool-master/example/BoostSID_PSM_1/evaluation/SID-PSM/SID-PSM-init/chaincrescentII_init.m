%only accepts even dimensions!
dim = 30;
tmp = 2*ones(dim,1);
for kk = 1:2:dim
	tmp(kk) = -1.5;
end
x_initial = tmp;