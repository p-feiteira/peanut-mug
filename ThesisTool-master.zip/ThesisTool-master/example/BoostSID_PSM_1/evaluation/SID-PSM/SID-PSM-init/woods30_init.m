%only accepts even dimensions!
dim = 30;
tmp = -ones(dim,1);
for kk = 1:2:dim
	tmp(kk) = -3;
end
x_initial = tmp;