dim = 30;
x_initial = [1:dim]';
