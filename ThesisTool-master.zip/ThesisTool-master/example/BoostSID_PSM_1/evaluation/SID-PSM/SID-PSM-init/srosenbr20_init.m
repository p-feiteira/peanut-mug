%only accepts even dimensions!
dim = 20;
tmp = ones(dim,1);
for kk = 1:2:dim
	tmp(kk) = -1.2;
end
x_initial = tmp;