dim = 10;
x_initial = 1/(dim+1)*[1:dim]'.*(1/(dim+1)*[1:dim]-1)';
