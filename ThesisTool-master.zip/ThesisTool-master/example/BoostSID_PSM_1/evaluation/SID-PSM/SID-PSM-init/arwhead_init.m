dim = 20;
x_initial = [1:dim]';