dim = 20;
x_initial = -ones(dim,1);