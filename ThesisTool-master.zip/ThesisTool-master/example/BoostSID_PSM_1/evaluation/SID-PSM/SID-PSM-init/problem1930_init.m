dim = 30;
x_initial = -ones(dim,1);