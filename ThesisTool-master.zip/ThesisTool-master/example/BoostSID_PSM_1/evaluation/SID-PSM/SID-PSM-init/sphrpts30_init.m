dim = 30;
x_initial = 4*pi/dim*[1:dim]'.*logical(mod([1:dim],2)~=0)';
