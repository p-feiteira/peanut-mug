dim = 10;
x_initial = [1:dim]';