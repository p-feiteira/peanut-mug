dim = 10;
x_initial = ones(dim,1);