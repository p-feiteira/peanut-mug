function test_parfeval()

dimensions = [6 10 20 30 40 50 60]; 
workers = [1 2 4 8 16];

files = {'bdqrtic', 'bertsekas'};

filename = 'parfeval_nodelay_nosearch.csv';
print_format = '%s,%d,%10.3e,%+13.8e,%+13.8e,%s,%d,%10.3e,%d,%d,%d,%d,%d,%d\n';
msg_format = 'Evaluating problem %s with dimension %d, version %s, %d workers. Started at %d/%d %d:%d\n';
fresult = fopen(filename,'w');
						
fprintf(fresult,"problem,dimension,time,f_final,alfa,version,wrks,evaltime,func_eval,iter,iter_suc,iter_uns,search_suc,delay\n");

const = 0;
output = 0;
search = 0;
cache = 1;
oportunistic = 1;
quad = 2;

delay = 0; %time in seconds

for w = 1:length(workers)
    
    wrks = workers(w);
    
    parpool([1 wrks]);
    
    poolobj = gcp('nocreate');
    poolsize = poolobj.NumWorkers;
    if poolsize ~= wrks
        fprintf(fresult,"%d workers not available. Program ended\n", wrks);
        break;
    end
    
    for ii = 1:length(dimensions)
        
        dim = dimensions(ii);
        def = ones(dim,1);
        
        x_initial = {def,1/sqrt(dim)*def};
        
        for jj = 1:length(files)
	
			c = clock;
			version = sprintf('%d%d%d%c%d', search, cache, oportunistic, 'q', quad);
			
			msg = sprintf(msg_format,files{jj},dim,version,wrks,c(3),c(2),c(4),c(5))
			
			[time,func_eval,f_final,alfa,evaltime,iter,iter_suc,iter_uns,search_suc,~] = ...
				sid_psm_parallel(x_initial{jj},const,output,files{jj},search,cache,oportunistic,quad,wrks,delay);
			
			fprintf(fresult,print_format, files{jj}, dim, time, f_final, alfa, version, wrks, ...
			evaltime, func_eval, iter, iter_suc, iter_uns, search_suc, delay);

        end
    end
    delete(gcp('nocreate'));
end
fclose(fresult);
end
