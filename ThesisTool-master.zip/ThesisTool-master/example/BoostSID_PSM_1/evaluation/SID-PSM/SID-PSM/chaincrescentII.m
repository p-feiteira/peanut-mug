function [f] = chaincrescentII(x);
%
% Purpose:
%
%    Function chaincrescentII is the chaincrescentII function in Haarala (2004) 
%    and computes the value of the objective function chaincrescentII.
%
%    dim = n
%    Suggested initial point for optimization:[-1.5 2 -1.5 2 ...]'
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
x1 = x(1:n-1);
x2 = x(2:n);
f  = sum(max(x1.^2+(x2-1).^2+x2-1,-x1.^2-(x2-1).^2+x2+1));
%
% End of chaincrescentII.
