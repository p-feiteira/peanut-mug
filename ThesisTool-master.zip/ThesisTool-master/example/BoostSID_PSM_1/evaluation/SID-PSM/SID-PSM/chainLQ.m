function [f] = chainLQ(x);
%
% Purpose:
%
%    Function chainLQ is the chainLQ function in Haarala (2004) 
%    and computes the value of the objective function chainLQ.
%
%    dim = n
%    Suggested initial point for optimization:-0.5*ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
x1 = x(1:n-1);
x2 = x(2:n);
f  = sum(max(-x1-x2,-x1-x2+(x1.^2+x2.^2-1)));
%
% End of chainLQ.
