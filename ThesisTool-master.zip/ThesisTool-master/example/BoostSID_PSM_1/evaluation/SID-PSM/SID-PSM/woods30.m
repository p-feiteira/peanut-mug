function [f] = woods(x);
%
% Purpose:
%
%    Function woods is a generalization for the
%    function in Appendix B of Dennis and Schnabel (1996)
%    and computes the value of the objective function woods.
%
%    dim >= 4 and multiple of 4
%    Suggested initial point for optimization:[-3 -1 -3 -1 ... -3 -1 -3 -1]'
%    Minimum point: [1 1 ...  1 1]'
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim  = floor(length(x)/4);
A    = 100*(x(1:4*dim-3,1).^2 - x(2:4*dim-2,1)).^2 + (1-x(1:4*dim-3,1)).^2 +...
       90*(x(3:4*dim-1,1).^2-x(4:4*dim,1)).^2 + (1-x(3:4*dim-1,1)).^2 +...
       10.1*((1-x(2:4*dim-2,1)).^2+(1-x(4:4*dim,1)).^2) + 19.8*(1-x(2:4*dim-2,1)).*...
       (1-x(4:4*dim,1));
mask = (mod([1:4*dim-3],4) == 1)';
f    = sum(A(logical(mask)));
%
% End of woods.
