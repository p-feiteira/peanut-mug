function [f] = chainmifflin2(x);
%
% Purpose:
%
%    Function chainmifflin2 is the chainmifflin2 function in Haarala (2004) 
%    and computes the value of the objective function chainmifflin2.
%
%    dim = n
%    Suggested initial point for optimization:-ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
x1 = x(1:n-1);
x2 = x(2:n);
f  = sum(-x1+2*(x1.^2+x2.^2-1)+1.75*abs(x1.^2+x2.^2-1));
%
% End of chainmifflin2.
