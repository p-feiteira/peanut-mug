function [f] = bdvalue(x);
%
% Purpose:
%
%    Function bdvalue is the Problem 28 in
%    Mor� and al (1981) and computes the value
%    of the objective function bdvalue.
%
%    dim >= 1
%    Suggested initial point for optimization: 1/(dim+1)*[1:dim]'.*
%                                              (1/(dim+1)*[1:dim]-1)'
%    Minimum value: 0
%
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim        = length(x);
x(2:dim+1) = x;
x(1)       = 0;
x(dim+2)   = 0;
T          = 1/(dim+1) * [1:dim]';
f          = sum((2*x(2:dim+1) - x(1:dim) - x(3:dim+2) +...
             (1/(dim+1))^2 * (x(2:dim+1) + T + 1).^3/2).^2);
%
% End of bdvalue.
