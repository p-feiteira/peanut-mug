function [f] = penalty2(x);
%
% Purpose:
%
%    Function penalty2 is the Problem 24 in
%    Mor� and al (1981) and computes the value
%    of the objective function penalty2.
%
%    dim >= 1
%    Suggested initial point for optimization:[0.5 ... 0.5]'
%    Minimum value: 9.37629E-6 , if dim = 4
%                   2.93660E-4 , if dim = 10
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim = length(x);
y   = exp([2:dim]/10)' + exp([1:dim-1]/10)';
f   = (x(1) - 0.2)^2 + sum((exp(x(2:dim)/10) + exp(x(1:dim-1)/10) - y(1:dim-1)).^2) * 10^-5;
i   = dim+1 - [1:dim]';
f   = f + sum((exp([2:dim]/10)' - exp(-1/10)).^2)*10^-5 + (sum(i.*(x.^2)) - 1)^2;
%
% End of penalty2.
