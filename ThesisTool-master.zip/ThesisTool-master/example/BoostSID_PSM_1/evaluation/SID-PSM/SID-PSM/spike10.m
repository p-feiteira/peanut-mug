function [f] = spike(x);
%
% Purpose:
%
%    Function spike is the spike function in Hare and Sagastiz�bal (2006) 
%    and computes the value of the objective function spike.
%
%    dim = n
%    Suggested initial point for optimization:[1 zeros(1,n-1)]'
%    Optimum value: 0
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
f = sqrt(norm(x));
%
% End of spike.
