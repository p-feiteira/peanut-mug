function [f] = waterfalls(x);
%
% Purpose:
%
%    Function waterfalls is the waterfalls function in Hare and Sagastiz�bal (2006) 
%    and computes the value of the objective function waterfalls.
%
%    dim = n
%    Suggested initial point for optimization:ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
function [g]=aux(y)
if (y<=0)
    g = y^2;
else
    stop  = 0;
    if (y>=1)
       index = 1;
       while ~stop
        if y<=(2^index)
            stop = 1;
            g    = -2^(-index+1)*(y-2^index)^2+2^index;
        else
            index = index + 1;
        end
       end
    else
       index = 0;
       while ~stop
        if y>=(2^(index-1))
            stop = 1;
            g    = -2^(-index+1)*(y-2^index)^2+2^index;
        else
            index = index - 1;
        end
       end
    end
end
end

n  = length(x);
for i=1:n
    v(i)= aux(x(i));
end    
f = sum(v);   
end
%
% End of waterfalls.
