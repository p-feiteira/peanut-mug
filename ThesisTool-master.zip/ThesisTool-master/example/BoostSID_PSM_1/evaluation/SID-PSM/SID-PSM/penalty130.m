function [f] = penalty1(x);
%
% Purpose:
%
%    Function penalty1 is the Problem 23 in
%    Mor� and al (1981) and computes the value
%    of the objective function penalty1.
%
%    dim >= 1
%    Suggested initial point for optimization:[1 : dim]'
%    Minimum value: 2.24997E-5 , if dim = 4
%                   7.08765E-5 , if dim = 10
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim = length(x);
f   = sum((x-1).^2) * 10^-5 + (sum(x.^2) - 1/4)^2;
%
% End of penalty1.
