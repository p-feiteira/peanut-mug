function [f] = broydn3d(x);
%
% Purpose:
%
%    Function broydn3d is the Problem 30 in
%    Mor� and al (1981) and computes the value
%    of the objective function broydn3d.
%
%    dim >= 1
%    Suggested initial point for optimization:[-1 ... -1]'
%    Minimum value: 0
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim        = length(x);
x(2:dim+1) = x;
x(1)       = 0;
x(dim+2)   = 0;
f          = sum(((3 - 2*x(2:dim+1)).* x(2:dim+1) - x(1:dim) - 2*x(3:dim+2) +1 ).^2);
%
% End of broydn3d.
