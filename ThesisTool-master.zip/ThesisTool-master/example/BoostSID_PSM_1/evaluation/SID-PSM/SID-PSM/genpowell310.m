function [f] = genpowell3(x);
%
% Purpose:
%
%    Function genpowell3 is a generalization for the function
%    in section 9 of Powell (1998) and computes the value of
%    the objective function genpowell3.
%    Not in CUTEr collection.
%
%    dim >= 2 and multiple of 2
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim  = floor(length(x)/2);
A    = (x(1:2*dim-1) - x(2:2*dim) + 0.2).^2 +...
       10^-4*(x(1:2*dim-1) + x(2:2*dim) + 77).^2;
mask = mod([1:2*dim-1],2)';
f    = sum(A(logical(mask)));
%
% End of genpowell3.
