function [f] = integreq(x);
%
% Purpose:
%
%    Function integreq is the Problem 29 in
%    Mor� and al (1981) and computes the value
%    of the objective function integreq.
%
%    dim >= 1
%    Suggested initial point for optimization: 1/(dim+1)*[1:dim]'.*(1/(dim+1)*[1:dim]-1)'
%    Minimum value: 0
%
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim      = length(x);
T        = 1/(dim+1) * [1:dim]';
CS1      = cumsum(T .* (x+T+1).^3);
CS2      = (1 - T(2:dim)) .* (x(2:dim) + T(2:dim)+1).^3;
I        = dim - [1:dim-1]';
CS2      = cumsum(CS2(I));
CS2      = CS2(I);
CS2(dim) = 0;
if dim == 2
    CS2 = CS2';
end
f        = sum((x + 1/(dim+1) * ((1-T).*CS1 + T(1:dim).*CS2) /2).^2);
%
% End of integreq.
