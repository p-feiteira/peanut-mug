function [f] = problem20(x);
%
% Purpose:
%
%    Function problem20 is the problem20 function in Haarala (2004) 
%    and computes the value of the objective function problem20.
%
%    dim = n
%    Suggested initial point for optimization:-ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
x1 = [0 x(1:n-1)']';
x2 = [x(2:n)' 0]';
f  = max(abs((0.5*x-3).*x-1+x1+2*x2));
%
% End of problem20.
