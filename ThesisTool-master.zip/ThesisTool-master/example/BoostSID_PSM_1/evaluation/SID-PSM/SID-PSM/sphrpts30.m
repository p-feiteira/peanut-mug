function [f] = sphrpts(x);
%
% Purpose:
%
%    Function sphrpts is described in Powell (DAMTP 2004)
%    and computes the value of the objective function sphrpts.
%
%    dim >= 2 and multiple of two
%    Suggested initial point for optimization:
%               4*pi/dim*[1:dim]'.*logical(mod([1:dim],2)~=0)'
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%

dim  = length(x);
Div2 = logical(mod([1:dim],2)==0);
P    = [cos(x(~Div2)').*cos(x(Div2)');sin(x(~Div2)').*cos(x(Div2)');sin(x(Div2)')];
dimP = dim/2;
%
for i = 1:dimP
   for j = 1:dimP
      M(i,j) = norm(P(:,i)-P(:,j));
   end
end
M = triu(M.^-2,1);
f = sum(sum(M));
%
% End of sphrpts.
