function [f] = activefaces(x);
%
% Purpose:
%
%    Function activefaces is the activefaces function in Haarala (2004) 
%    and computes the value of the objective function activefaces.
%
%    dim = n
%    Suggested initial point for optimization:ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
function [g] = aux(y);
g = log(abs(y)+1);
end

n  = length(x);
for i = 1:n
    v(i) = aux(x(i));
end
v(n+1) = aux(-sum(x));
f      = max(v);
end
%
% End of activefaces.
