function [f] = problem6(x);
%
% Purpose:
%
%    Function problem6 is the problem6 function in Haarala (2004) 
%    and computes the value of the objective function problem6.
%
%    dim = n
%    Suggested initial point for optimization:-ones(n,1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
x1 = [0 x(1:n-1)']';
x2 = [x(2:n)' 0]';
f  = max(abs((3-2*x).*x+1-x1-x2));
%
% End of problem6.
