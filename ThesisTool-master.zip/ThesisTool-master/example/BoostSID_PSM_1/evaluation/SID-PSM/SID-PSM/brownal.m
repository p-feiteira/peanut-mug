function [f] = brownal(x);
%
% Purpose:
%
%    Function brownal is the Problem 27 in
%    Mor� and al (1981) and computes the value
%    of the objective function brownal.
%
%    dim >= 1
%    Suggested initial point for optimization:[0.5 ... 0.5]'
%    Minimum value: 0
%
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim   = length(x);
f     = sum((x(1:dim-1) + sum(x) - (dim+1)).^2) + (prod(x)-1)^2;
%
% End of brownal.
