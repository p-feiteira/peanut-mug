function [f] = problem22(x);
%
% Purpose:
%
%    Function problem22 is the problem22 function in Haarala (2004) 
%    and computes the value of the objective function problem22.
%
%    dim = n
%    Suggested initial point for optimization:[1:n]'/(n+1).*([1:n]'/(n+1)-1)
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at y).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version September 2006.
%
%
n  = length(x);
I  = [1:n]';
x1 = [0; x(1:n-1)];
x2 = [x(2:n); 0];
f = max(abs(2*x+1/(2*(n+1)^2)*(x+I/(n+1)+1).^3-x1-x2));
%
% End of problem22.
