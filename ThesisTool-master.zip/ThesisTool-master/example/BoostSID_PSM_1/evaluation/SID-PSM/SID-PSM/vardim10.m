function [f] = vardim(x);
%
% Purpose:
%
%    Function vardim is the Problem 25 in
%    Mor� and al (1981) and computes the value
%    of the objective function vardim.
%
%    dim >= 1
%    Suggested initial point for optimization:(1-[1 : dim]/dim)'
%    Minimum point: [1 ... 1]'
%    Minimum value: 0
%
%
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim = length(x);
I   = [1:dim]';
f   = sum((x-1).^2) + sum(I.*(x-1))^2 + sum(I.*(x-1))^4;
%
% End of vardim.
