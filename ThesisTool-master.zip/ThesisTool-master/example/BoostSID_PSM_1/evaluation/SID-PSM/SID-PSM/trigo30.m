function [f] = trigo(x);
%
% Purpose:
%
%    Function trigo is the trigonometric function in Appendix B
%    of Dennis and Schnabel (1996) and computes the value of the
%    objective function trigo.
%
%    dim >= 1
%    Suggested initial point for optimization: 1/dim*ones(dim,1)
%    Minimum value: 0
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim  = length(x);
vaux = [1:dim]';
A    = (dim - sum(cos(x)) - dim*(vaux.*(1-cos(x)) - sin(x))).^2;
f    = sum(A);
%
% End of trigo.
