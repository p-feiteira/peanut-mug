function [f] = chrosen(x);
%
% Purpose:
%
%    Function chrosen is taken from Toint(1978), except that some
%    of its parameters are set to one, and computes the value
%    of the objective function chrosen.
%    Not in CUTEr collection.
%
%    dim >= 2
%    Suggested initial point for optimization:-[1 ... 1]'
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version April 2004.
%
%
dim = length(x);
A   = 4*(x(1:dim-1) - x(2:dim).^2).^2 + (1-x(2:dim)).^2;
f   = sum(A);
%
% End of chrosen.
