
                          BoostSID_PSM Version 0.2
                          ========================

                                 Read me
                               ----------


Welcome to BoostSID_PSM Version 0.2 September, 2020!

This file describes the following topics:


1. System requirements
2. Third party codes
3. Installation
4. Contents of the BoostSID_PSM_0.2 directory 
5. The command line
6. Regarding parallel execution
7. The BoostSID_PSM team and web site 
8. Acknowledgments


1. System requirements
----------------------------------------

Your computer should have a Matlab numerical compiler installed. If you plan
to use the current search option implemented in BoostSID_PSM, based on minimum Frobenius
norm  models, then you need a solver for the solution of the trust-region subproblems.
If you chose to use trs function (which is based on dgqt routine from MINPACK2 [1]) 
then you should also have installed a Fortran compiler. Otherwise you need to have 
the Matlab function trust.m, which is part of the Matlab Optimization toolbox.

Reference:

[1] J. J. Mor�, D. C. Sorensen, K. E. Hillstrom and B. S. Garbow, The MINPACK
    Project, in Sources and Development of Mathematical Software, W. J. Cowell, ed., 
    Prentice-Hall, NJ, 1984, pp. 88--111.


2. Third party codes
----------------------------------------

If you plan to use the search option of BoostSID_PSM then, depending of the choice 
of solver for the trust-region subproblems, one of the following third party 
components is required:

trs_solver = 1: dgqt subroutine from MINPACK2 [1], jointly distributed with
                BoostSID_PSM files.

trs_solver = 0: trust.m Matlab file, from the Matlab Optimization toolbox.

Reference:

[1] J. J. Mor�, D. C. Sorensen, K. E. Hillstrom and B. S. Garbow, The MINPACK
    Project, in Sources and Development of Mathematical Software, W. J. Cowell, ed., 
    Prentice-Hall, NJ, 1984, pp. 88--111.


3. Installation
----------------------------------------

The code requires approximately 650Kb of hard disk space. If you are running
the code on an Unix/Linux platform, then the following commands should be 
executed to unpack the compressed files:

        gunzip -c BoostSID_PSM_0.2.tar.gz | tar xvf -

In a Windows platform use Unzip for the same purpose.

A directory named BoostSID_PSM_0.2 will be created, either in Windows or
Unix/Linux operating systems. This directory must be moved to a working
directory in the Matlab tree. Alternatively, the Matlab path could be
updated accordingly.

The BoostSID_PSM parameters can be modified in the file parameters.m
under the BoostSID_PSM_0.2 directory. 


4. Contents of the BoostSID_PSM_0.2 directory
----------------------------------------

In the directory BoostSID_PSM_0.2 there are the following files:

  driver_const.m                A driver for constrained problems.

  driver_unconst.m              A driver for unconstrained problems.
  
  driver_const_parallel.m       A driver for constrained problems, using parallelism.

  driver_unconst_parallel.m     A driver for unconstrained problems, using parallelism.

  README.txt                    The current file.

  ---------------------------
  User provided Matlab files:
  ---------------------------

  arwhead.m            A sample problem that computes the value of the 
                       objective function (used for unconstrained optimization).
  
  arwhead_init.m       Initialization point for the sample problem.

  driver_example.m     A second sample problem that computes the value of the
                       objective function (used for constrained optimization).

  func_const.m         To compute the values of the constraint functions.

  grad_const.m         To compute the gradients of the constraint functions.

  -----------------------
  Optimizer Matlab files:
  -----------------------

  domain.m             To check the feasibility of a given point.

  eval_point.m         To evaluate a given function at a given 
                       point (required for the parallel version).

  gen.m                To compute the positive spanning set to be used by
                       the pattern search method.

  grad_act.m           To determine the approximated active constraints.

  lambda_poised.m      To compute a \Lambda-poised set from a given
                       set of points.

  match_point.m        To check if a point has been previously evaluated.

  mesh_proc.m          To update the mesh size parameter.

  new_quad_Frob.m      To compute a quadratic interpolation model for the
                       objective function, in the underdetermined case by
                       minimizing the Frobenius norm of the Hessian matrix
					   (updated version).

  order_proc.m         To reorder the columns of a given matrix according
                       to the angles between them and a given vector.

  parameters.m         A file with default values for the parameters to be
                       used by BoostSID_PSM.

  proj_ort.m           To compute the orthogonal projection of a given point
                       in a feasible region defined through bounds on the
                       problem variables.

  prune_dir.m          To prune the columns of a given matrix according
                       to the angles between them and a given vector.

  BoostSID_PSM.m             The main program. Applies a pattern search method 
                       to the user's problem.
					   
  BoostSID_PSM_parallel.m   (NEW) Parallel version of the main program.

  simplex_deriv.m      To compute simplex derivatives from a given set of
                       points.

The remaining files in the directory concern the use of the subroutine dgqt 
from MINPACK2 [1].

Reference:

[1] J. J. Mor�, D. C. Sorensen, K. E. Hillstrom and B. S. Garbow, The MINPACK
    Project, in Sources and Development of Mathematical Software, W. J. Cowell, ed., 
    Prentice-Hall, NJ, 1984, pp. 88--111.


5. The command line 
----------------------------------------
 
Before running BoostSID_PSM, the user should provide the necessary
information about the objective function. The name of this file should 
be given as a parameter ('problem'). Alternatively, the objective function
can be directly coded at file driver_example.m

If there are any constraints, the user must supply the corresponding
information in the files func_const.m and grad_const.m.

Next, at the directory BoostSID_PSM_0.2, the user should type:

              BoostSID_PSM(x_initial,const,output,problem)

For the parallel version, the command line is:

              BoostSID_PSM_parallel(x_initial,const,output,problem)

The following data has to be provided:

  - x_initial (the initial point to start the optimizer);

  - const (0 if the problem is unconstrained; 1 if the problem is constrained;
          2 if the constraints are only bounds);

  - output (0-2 variable: 0 - no output; 1 - verbose; 
           2 - very verbose).
		   
  - problem (name of the problem file; should be in the same
		     directory as BoostSID_PSM or BoostSID_PSM_parallel).
 
For a quick start, or to confirm that the BoostSID_PSM installation was
completed successfully, the user can run the drivers driver_unconst.m,
driver_const.m or their parallel versions driver_unconst_parallel.m
and driver_const_parallel.m.

6. Regarding parallel execution
----------------------------------------

The code BoostSID_PSM_parallel.m features two sections labelled "%%%PARPOOL%%%".
The parallel pool represents the pool of specified workers and is required
to use parallelism. These sections manage creation and deletion of parallel
pools.

We opted to include them in the code to ease single executions,but creating 
parallel pools is a lengthy process. For multiple executions with the same 
number of processors, an adaptation of the code is recommended: parts labelled
"%%%PARPOOL%%%" should be deleted and the creation and deletion of parallel 
pools would be done outside BoostSID_PSM_parallel.m, in the matlab command line or
on a possible custom user file designed to test for multiple runs.

More on parallel pools:
https://www.mathworks.com/help/parallel-computing/parpool.html;jsessionid=2df7eb0509265e45c5869173dce0

7. The BoostSID_PSM team and web site 
----------------------------------------

Current BoostSID_PSM team:

   Ana Luisa Custodio (Universidade Nova de Lisboa).
   V�tor Duarte (Universidade Nova de Lisboa).
   Pedro Medeiros (Universidade Nova de Lisboa).
   S�rgio Tavares (Universidade Nova de Lisboa).
   Luis Nunes Vicente (University of Coimbra). 

The BoostSID_PSM web site is located at:
https://docentes.fct.unl.pt/algb/pages/boostdfo

8. Acknowledgments
----------------------------------------

BoostSID_PSM team thanks BLAS, LAPACK and MINPACK2 teams for authorizing 
the distribution and use of subroutines jointly with BoostSID_PSM.
