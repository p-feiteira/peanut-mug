addpath('F:\Users\pedro\Documents\GitHub\ThesisTool\example\BoostSID_PSM_1\evaluation\SID-PSM\SID-PSM');
addpath('F:\Users\pedro\Documents\GitHub\ThesisTool\example\BoostSID_PSM_1\evaluation\SID-PSM\SID-PSM-init');
run("bertsekas_init");
BoostSID_PSM(x_initial,0,1,'bertsekas');