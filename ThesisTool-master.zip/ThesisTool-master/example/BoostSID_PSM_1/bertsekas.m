function [f] = bertsekas(x);
%
% Purpose:
%
%    Function bertsekas is the function in the example 3 of Bogani, Gasparo  
%    and Papini(2006) and computes the value of the objective function 
%    bertsekas.
%
%    dim = n
%    Suggested initial points for optimization: eps/sqrt(n)*ones(n,1)
%    eps = 0.01,1,100
%    Optimum value: 1
%
% Input:  
%
%         x (point given by the optimizer).
%
% Output: 
%
%         f (function value at x).
%
% Written by A. L. Custodio and L. N. Vicente.
%
% Version October 2006.
%
%
n   = length(x);
aux = [1:n]';
f   = (1+sum(aux.*abs(x)))^2;
%
% End of bertsekas.
