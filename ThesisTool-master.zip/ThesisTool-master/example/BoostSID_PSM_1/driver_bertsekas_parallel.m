run("bertsekas_init");
BoostSID_PSM_parallel(x_initial,0,1,'bertsekas');