
# Tool:

## Components:

Base requirements:

* Windows / UNIX / OSX
* [Octave](https://www.gnu.org/software/octave/#install)

## Local tool

This tool takes the client's PC cores and threads and executes the requested project in parallel.

## Remote Arquitecture

![Arq](./arq.png)

This tool is composed by three components:
1. Client, that will be use the tool and configure the resources that will be used.
2. Proxy, that controls and distributes the traffic received to the backend servers.
3. Servers, that executes the information received from proxy.

Besides what is represented, the remote service can be deployed in [Azure](https://azure.microsoft.com/) (cloud) as virtual machines (VMs) and it could be aggrouped inside a cluster.

## Initial considerations

* The C programs created on this tool, can be always recompiled by using *gcc* command, but the extension to create the C object is dependent of the Operating System:
  * In windows, the object is interpreted as an executable file (.exe). Which means that to recompile a C file in Windows, the command should be: gcc -o \<filename\>.exe c_files.c
  * In UNIX/OSX systems, the C object (.o), should be recompiled as: gcc -o \<filename>\.o c_files.c

## Base file

![Config](./configuration.PNG)

This is the file that configure the base of the tool.
It contains entries that must be filled and some optional entries.

It **must** be filled:

* **type**
  * **local**, the tool executes the client's project in parallel, but locally.
  * **remote**, the tool connects to the service proxy and executes the client's code in parallel, remotely.
* **folders**, the necessary directories for the tool to work.
* **environment**, where Octave is the default. Other programming languages are supported only in static execution.

Optional

* **ip/port**. When the remote execution is choosed, the client must configure the proxy's endpoint.

### Client

* ~~[MinGW](http://www.mingw.org/)~~ On Windows, it comes with Octave Installer. On UNIX / OSX this tool is not necessary;
* OpenSSH Client;
* ~~uuid.h (It not comes with Ubuntu, should be install as 'sudo apt-get install uuid-dev)'~~

#### Headers

Headers that are and could common to all developed functions.

##### Directory.h

Header file used to get the current workspace directory in runtime.

##### OS_header.h

Header file that has some properties that differs based on the Operating System used, such as the command script file's extension (batch file for Windows and shell script for Unix systems).

#### HTTP

##### connectionTest.c

Simple C file that could be used to test the client functions.

##### client.c

C file that contains all the HTTP requests/responses between a client and the webservice. It contains:

* Header builder
* File and request uploading (sendData())
* Direct function request upload (sendDataByIndex())
* Response Header parser (parseHeader())
* Response Body parser (parseBody())
* Get execution result function that will run in background (get()) ~~**(Fix Needed)**~~

###### How to test it separatly from the whole project, if needed?

gcc -o clientTest.(exe/o) connectionTest.c [-l ws2_32]

The -l flag should be used only on Windows.

##### client.h

Header C file that contains the imports and generic socket functions to be interpreted by Windows and Unix Systems.

##### operations.c

C file that has all logic of webservice's HTTP requests.

#### Main folder

This folder has all .mex/.m files of the project. 
All the .mex files are the compiled version of .c files that (were / will be) explained.

##### Folders

Main folder has all the default directories for the tool to work.
* finished: finished executions. Where the results received from the webservice and the local executions are stored;
* history: folder with the processed finished files;
* local: default folder used on local executions
  * ~~outputs~~(removed for simplicity)
  * run
* remote: default folder used on remote executions;
  * pending folder: where the requests are stored. Files from this folder are moved to the finished folder when the webservice send the result of the execution.

##### execute.m

Simple script that is used only to bind Octave to the tool.

##### parseParams.m

Script file that is used to translate the functions's arguments to a String.

##### mainCompile.m / unix_mainCompile.m

Script that is used to compile all the project's .mex files.

The command to run it is : octave [unix_\]mainCompile.m (considering that the current folder is ./client/src/main)

#### Tool

##### background/functions.c

C file that contains all the functions that are used in threads.

##### concurrent.c

C file that has the functions that create threads.

##### configParser.c

C file that parse properties files.

##### Directory.c

C file that returns the current directory of workspace.

##### executionTool.c

Project's main octave script. The project has 4 ways to execute:
* Local
  * Dynamic (When the executions are only a few blocks of the project that will be executed)
* Remote
  * Static (The client's project will be sent to the remote service and it will be executed sequentially. This mode supports octave/maltab, java/jar and c projects).
  * Dynamic (Each client's project loop step are sent to the remote service and proceses in parallel).

##### next.c

C file that is used to manage the files inside finished folder. It should have the same behaviour as MATLAB's *fetchNext()*

##### fetch.c

It will be check the finished folder and get the next result that could be used to realize the final calculations. It can be sorted after all fetched results. 

##### remoteRun.c

Script used on static remote mode. It creates the necessary files (and zip it) that will be needed to the webservice to execute the requested functions.

##### tool.c

Contains all the project's logic. It processes the request based on type (remote/local) and mode (static/dynamic).

##### ~~uniqueID.c~~

~~C file that generate a UUID (**U**niversally **U**nique **ID**entifier). It is used to avoid collisions.~~

##### env.properties

Properties file that has all the supported programming languages by tool's statil mode.

### init Folder

This folder contains all the scripts and files needed to launch the tool before remote usage.

The remote version supports two ways for launching the tool. 

From knowning hosts, which means that the client has all informations needed from all the machines that will be used to launch the tool, using classic servers or [Azure](https://azure.microsoft.com/). To use it, the cliente needs to fill as wanted the *nodes.properties* file, inside hosts folder.

The other version is by using a cluster. This version uses a Docker image and it is necessary node reservation as Docker Swarm before usage.

#### docker Folder

##### service folder

Docker file to create the tool's Backend.

##### cluster_reservation.c

Guide written in C that helps a client to reserve the nodes that will be used by the cluster to run the tool.

##### cluster_launch.c

Based on the reservation made, this C program launch the tool.

##### remote.properties

![Remote](./remote.png)

* **remote_type**: (Do not change!) it specifies that will be used the cluster remote version of the tool.
* **host**: the cluster endpoint, that will be used to reserve and use nodes to launch the remote service.
* **ssh_port**: specific port that should be used in SSH connections.
* **port**: port that will be exposed to the internet, to be used by the client.
* **host_os**: Operating system of the cluster.
* **has_service**: The first time that the cluster will be used, this entry must be set as *'yes'*. After, this entry should be set to *'no'*, to save time. This option is used to upload all the information that will be used at cluster.

#### compile_hosts.c

C program that compiles all the programs inside hosts folder.

#### hosts folder

##### nodes.properties

![nodes](./nodes.png)

Each time the client want to add a Proxy or a Node, it should be specified with brackets (example in figure).

* **type**: type of machine that will be used: "classic", to use a machine or virtual machine that should be addressed by SSH or "azure" to create a **Microsoft Azure** virtual machine. By using "classic", **location** parameter should not be filled. If it will be used "azure", **host** parameter should not be filled.
* **host**: the SSH endpoint of a host to be used. If it will be used the Azure, this entry is not necessary to fill. 
* **ssh_port**: Specific ssh port that should be used in SSH connection. Not needed if Azure is used.
* **port**: Port that will be exposed to the internet of the machine/cloud VMs.
* **os**: Operating system of the machine that will be used / Azure VM's desired opertating system.
* **hasService**: The first time that this remote type will be used, this entry must be set as *'yes'*. After, this entry should be set to *'no'*, to save time. This option is used to upload all the information that will be used.
* **location**: Location for the Azure VM location. Should be filled only if Azure will be used. [More info](https://azure.microsoft.com/en-us/global-infrastructure/geographies/)

**Note:** Azure only supports Ubuntu images.

##### azure.c

C program that creates VMs on Microsoft Azure based on *nodes.properties* and uploads the tool to the VM's previously created.

##### nodes.c

C program that parse *nodes.properties* file.

##### prepare_hosts.c

C program that uploads the tool to the hosts that are specified on *nodes.properties*.

##### shutdown_azure.c / shutdown_hosts.c

When the tool is not more necessary, this C program should be used to shutdown the environment.
* For classic hosts, the processes that contains the tool are killed.
* For Azure VM, the VMs are dealocated. Which means that the VM still exists but are inactive, to save resources.

### static folder

In the case where it is necessary to run the client code sequentially but in other programming languages rather than octave/matlab, such as Java and C, the client's project should be executed in static mode.

#### staticTool.c

C program that zip, send to execute and receives the response of the project that was requested by the client.

### zips folder

Folder that contains the zips files of the tool's webservices.

## What are the options that tool has to execute client's project code

### ~~Locally~~ (Work in progress!)

1. ~~Configure *config.properties* file by setting the type entry to local;~~
2. ~~Set the correct folder paths;~~
3. ~~Add the tool's main folder path to the client's project and insert the desired tool operations;~~
4. ~~Launch the execution with **octave filename.m** command, in terminal.~~

### Remotely

1. Configure *config.properties* file by setting the type entry to remote;
2. Set the correct folder paths;

#### ~~Static~~

3. Run static tool C object with the main file of the project and its arguments, if exists. **staticTool.(o/exe) filename arg1 arg2**;

#### Cluster

3. Go inside init/docker folder and fill the *remote.properties* file with the requested information;
4. Run reservation C program: **reservation.(o/exe)** and follow its instructions;
5. Run launch C program: **launch.(o.exe) leaderNode**;
6. Add the tool's main folder path to the client's project and insert the desired tool operations; 
7. Run the project main file: **octave filename.m**.

#### Azure/Classic Machines/VMs

3. Go inside init/hosts folder and fill the *nodes.properties* file with the requested information;
4. Run prepare C program: **prepare_[hosts/azure].(o/exe)**;
5. Add the tool's main folder path to the client's project and insert the desired tool operations; 
6. Run the project main file: **octave filename.m**.
7. When the remote service is not more necessary, the client should run the shutdown C program: **shutdown_[hosts/azure].(o/exe)**.

### Simple example
There is a file to test: **testDynamic.m** inside the *example* folder. To run it:

1. The example use disp function. So it is not necessary to configure the **project_folder** entry.

2. Change directory to example folder: **"cd <workspace\-path>/client/src/main/"**

3. Run the .m file: **octave testDynamic\.m**

### SID-PSM

Verify the sidpsm_parallel.m file, inside *example* folder, to understand how the tool can be used in a real example. The *parfor* and *parfeval* functions were commented, allowing the comparison between the parallel tools that exist and this new tool.

How to run it:

1. First, the client should choose the way to execute its project, fill the *config.properties* file and the other corresponding execution type file, inside *init* folder.
  * Running locally or in static version of tool, the only file need is *config.properties*.
  * By using a cluster, it should be filled *remote.properties* file, inside docker folder.
  * By using azure or classic machines, it should be filled *nodes.properties* file, inside hosts folder.
2. Add the path of the tool's main folder to the file that is the logic of the project. In SID-PSM case, it should be inserted the main folder path inside *sidpsm_parallel.m* file.
3. The example file for execute SID-PSM is *driver_const_parallel.m* file. So, the client should insert the command : *octave driver_const_parallel.m* on the terminal and wait for the final results.