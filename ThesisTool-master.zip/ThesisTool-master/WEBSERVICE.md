# WebService

A [Java RESTful](https://eclipse-ee4j.github.io/jersey.github.io/documentation/latest/user-guide.html) web service that will run the octave code remotely.

## Requirements

* Java 11
* ~~Wildfly/Tomcat (to configure and launch the server)~~
* Maven
* OpenSSH Server
* Java IDE ([Eclipse](https://www.eclipse.org/), [IntelliJ](https://www.jetbrains.com/idea/)) **optional**

## Upload.java

It receives a zip file, unzip it and give it a unique ID. This ID is sent to the client. Now the client can get any information about its execution.

## Run.java

The web service launches several executions in parallel, bases on server's cpu threads capacity. It returns the process ids of each execution.

## Status.java

With the received ID and process IDs, the client can verify the status of a particular execution or the general execution status.

## DownloadRequest.java (not used, for now)

When all the tasks finish it is possible to get all the results from the web service. Thus, the web server creates a zip file with the execution outputs and send it to the client.

## DirectExec.java

Receives a requestID (if any) and the function that will be executed and it launches a thread that will execute it.

## Login.java (not used, for now)

Will be used to control the client's authentication.