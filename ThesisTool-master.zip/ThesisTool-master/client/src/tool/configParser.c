/* Parse the configuration file. That will originate the props structure. */

#include "../headers/OS_header.h"
#include "./Directory.c"

struct Properties
{
    char type[20];
    char ip[40];
    int port;
    char finished_folder[400];
    char project_folder[400];
    char environment[20];
};

static struct Properties *instance;

struct Properties* getProperties()
{
    struct Properties* props = (struct Properties*) malloc(sizeof(struct Properties));

    char *dir = getDirectory();
    char *path = (char *)malloc((strlen(dir) + strlen(PROPS_DIR) + 20) * sizeof(char));
    sprintf(path, "%s%c%s", dir, FILE_SEPARATOR, PROPS_DIR);

    FILE *fp = fopen(path, "r");

    if (!fp)
    {
        perror("ERROR configParser");
        printf("\n\npath configparser -> %s\n\n", path);
        exit(1);
    }

    char buff[256];
    char *token;
    char *key;
    char *value;
    while (!feof(fp))
    {
        if(!fgets(buff, 256, fp)){
            continue;
        }
        if (strstr(buff, "#") || !strstr(buff, "="))
        {
            continue;
        }

        token = strtok(buff, "\n");
        key = strtok(token, "=");
        value = strtok(NULL, "=");

        if (strstr(key, "type"))
        {
            strcpy(props->type, strtok(value, "\r"));
        }
        if (strstr(key, "ip"))
        {
            strcpy(props->ip, strtok(value, "\r"));
        }
        if (strstr(key, "port"))
        {
            props->port = atoi(strtok(value, "\r"));
        }
        if (strstr(key, "finished_folder"))
        {
            strcpy(props->finished_folder, strtok(value, "\r"));
        }
        if (strstr(key, "project_folder"))
        {
            strcpy(props->project_folder, strtok(value, "\r"));
        }
        if (strstr(key, "environment"))
        {
            strcpy(props->environment, strtok(value, "\r"));
        }
    }
    
    fclose(fp);
    free(path);
   
    return props;
}

struct Properties* getInstance(){

    if(instance == NULL){
        instance = getProperties();
    }

    return instance;
}