#include "tool.c"
#include "mex.h"

#if _WIN32

#define fopen_verification() \
    {                        \
    }
#else

#define FOPENS 1024

#define fopen_verification()                              \
    {                                                     \
        FILE *fp = popen("ulimit -n", "r");               \
                                                          \
        int result;                                       \
                                                          \
        if (!fscanf(fp, "%d", &result))                   \
                                                          \
        {                                                 \
                                                          \
            perror("ERROR fscanf");                       \
                                                          \
            exit(1);                                      \
        }                                                 \
                                                          \
        if (result <= FOPENS)                             \
        {                                                 \
            system("prlimit --pid=$PPID --nofile=65535"); \
        }                                                 \
        pclose(fp);                                       \
    }

#endif