// C program for array implementation of queue
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

struct data
{
    int idx;
    char *result;
};

// A structure to represent a queue
struct Queue
{
    int front, rear, size;
    unsigned capacity;
    struct data *array;
};

// function to create a queue
// of given capacity.
// It initializes size of queue as 0
struct Queue *createQueue(unsigned capacity)
{
    struct Queue *queue = (struct Queue *)malloc(
        sizeof(struct Queue));
    queue->capacity = capacity;
    queue->front = queue->size = 0;

    // This is important, see the enqueue
    queue->rear = capacity - 1;
    queue->array = (struct data *)malloc(
        queue->capacity * sizeof(struct data));
    return queue;
}

// Queue is full when size becomes
// equal to the capacity
int isFull(struct Queue *queue)
{
    return (queue->size == queue->capacity);
}

// Queue is empty when size is 0
int isEmpty(struct Queue *queue)
{
    return (queue->size == 0);
}

// Function to add an item to the queue.
// It changes rear and size
void enqueue(struct Queue *queue, struct data item)
{
    if (isFull(queue))
        return;
    queue->rear = (queue->rear + 1) % queue->capacity;
    queue->array[queue->rear] = item;
    queue->size = queue->size + 1;
}

// Function to remove an item from queue.
// It changes front and size
struct data dequeue(struct Queue *queue)
{
    if (isEmpty(queue))
    {
        struct data none = {.idx = -1, .result="None"};
        printf("Queue is empty\n\n");
        return none;
    }
    else
    {
        struct data item = queue->array[queue->front];
        queue->front = (queue->front + 1) % queue->capacity;
        queue->size = queue->size - 1;
        return item;
    }
}

// Function to get front of queue
struct data front(struct Queue *queue)
{
    if (isEmpty(queue))
    {
        struct data none = {.idx = -1, .result="None"};
        printf("Queue is empty\n\n");
        return none;
    }
    else
    {
        return queue->array[queue->front];
    }
}

// Function to get rear of queue
struct data rear(struct Queue *queue)
{
    if (isEmpty(queue))
    {
        struct data none = {.idx = -1, .result="None"};
        printf("Queue is empty\n\n");
        return none;
    }
    else
    {
        return queue->array[queue->rear];
    }
}

struct data dequeueLast(struct Queue *queue)
{
    if (isEmpty(queue))
    {
        struct data none = {.idx = -1, .result="None"};
        printf("Queue is empty\n\n");
        return none;
    }
    else
    {
        struct data item = queue->array[queue->rear];
        queue->rear = (queue->rear - 1) % queue->capacity;
        queue->size = queue->size - 1;
        return item;
    }
}

// Driver program to test above functions./
int main()
{
    struct Queue *queue = createQueue(1000);

    struct data d1 = {.idx = 1, .result = "1"};
    struct data d2 = {.idx = 2, .result = "2"};
    struct data d3 = {.idx = 3, .result = "3"};
    struct data d4 = {.idx = 4, .result = "4"};

    enqueue(queue, d1);
    enqueue(queue, d2);
    enqueue(queue, d3);
    enqueue(queue, d4);

    printf("%d dequeued from queue\n\n",
           dequeue(queue).idx);

    printf("Front item is %d\n", front(queue).idx);
    printf("Rear item is %d\n", rear(queue).idx);

    return 0;
}