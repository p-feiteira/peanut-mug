/* C file that is used to create the execute Octave function */

#include "executionTool.h"

#define HOSTS_TXT "hosts.txt"

int startConfig = 1;
int init = 1;
struct Properties* properties;

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{

    if (init)
    {
        fopen_verification();
        init = 0;
        properties = getInstance();
        createFolders();
    }

    mwSize n;
    mwIndex i;

    n = mxGetNumberOfElements(prhs[1]);

    char **matrix = (char **)malloc(n * sizeof(char *));

    int size = 0;

    for (i = 0; i < n; i++)
    {
        char *ptr = mxArrayToString((mxGetCell(prhs[1], i)));
        matrix[i] = (char *)calloc(strlen(ptr) + 2, sizeof(char));
        size = size + strlen(ptr) + 2;
        strcpy(matrix[i], ptr);
    }

    if (strstr(properties->type, "local"))
    {
        int idx = mxGetScalar(prhs[0]);
        dynamicLocalExec(properties, idx, i, matrix, size);
    }
    else if (strstr(properties->type, "remote"))
    {
        char *function;
        if (startConfig)
        {
            startConfig = 0;
            char *dir = getDirectory();
            char hosts_p[strlen(HOSTS_TXT) + strlen(dir) + 2];
            sprintf(hosts_p, "%s%c%s", dir, FILE_SEPARATOR, HOSTS_TXT);
            config(properties, hosts_p);
            addProj(properties);
        }

        int idx = mxGetScalar(prhs[0]);
        function = directRemoteExec(i, matrix, size);
        sendFunction(properties, function, idx);
    }

}