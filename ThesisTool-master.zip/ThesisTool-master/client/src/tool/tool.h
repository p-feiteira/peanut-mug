#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include "utils.c"

struct matrixSize{
char*** matrix;
char** function_names;
int total;
int row;
int column;
};

#if _WIN32
#define SHELL "cmd.exe"
#define SHELL_ARG "/c"
#define STDOUT "nul"
#define pause(t){\
Sleep(t*1000);\
}
#define TIMEOUT_PRINT "Restart by executing start_background_thread.exe\n"
#else
#include <unistd.h>
#define SHELL "/bin/sh"
#define SHELL_ARG "-c"
#define STDOUT "/dev/null"
#define pause(t){\
sleep(t);\
}
#define TIMEOUT_PRINT "Restart by executing start_background_thread.o\n\n"
#endif
