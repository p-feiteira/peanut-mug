#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "../http/operations.c"

#define ZIP "/remote/proj.zip"
#define CONFIG "/remote/cfg.properties"
#define PROJ "/remote/currentProj.txt"

/**
 * Creates a directory
 *
 * dir - New folder's directory
 *
 */
static void __mkdir(const char *dir)
{
    char tmp[256];
    char *p = NULL;
    size_t len;

    snprintf(tmp, sizeof(tmp), "%s", dir);
    len = strlen(tmp);
    if (tmp[len - 1] == '/')
        tmp[len - 1] = 0;
    for (p = tmp + 1; *p; p++)
        if (*p == '/')
        {
            *p = 0;
            make_directory(tmp);
            *p = '/';
        }
    make_directory(tmp);
}

/**
 * Octave's fileparts C implementation
 *
 * p - file path
 *
 */
char **fileparts(char p[])
{
    //[direct, n, ext]
    char **result = (char **)calloc(3, sizeof(char *));
    char *temp = strdup(p);
    int extension_pos = strlen(temp);
    for (int i = (strlen(temp) - 1); i >= 0; i--)
    {
        if (temp[i] == '.')
        {
            extension_pos = i;
            result[2] = calloc(10, sizeof(char));
            strncpy(result[2], temp + i, strlen(temp) - i);
        }
        if (temp[i] == '\\' || temp[i] == '/')
        {
            size_t l = (strlen(temp) - 1) - i - (strlen(temp) - extension_pos);
            result[1] = calloc(l + 3, sizeof(char));
            strncpy(result[1], temp + i + 1, (strlen(temp) - (i + 1) - (strlen(temp) - extension_pos)));
            result[0] = calloc(i + 2, sizeof(char));
            strncpy(result[0], temp, i);
            if (extension_pos == strlen(p))
            {
                result[2] = calloc(1, sizeof(char));
                strcpy(result[2], "\0");
            }

            return result;
        }
    }
    return NULL;
}

/**
 * Zip the files that are used by the tool
 *
 * props - Structure that contains the tool configuration properties
 * functionFile - path of file that contains Octave's fragment informations
 * config_dir - configuration file path that will be zipped
 * zip_dir - final zip directory. Where the zip file will be stored when completed
 * 
 */
char *zip(struct Properties* props, char *functionFile, char *config_dir, char *zip_dir)
{

    char buffer[1024];

    if (!functionFile)
    {
        functionFile = "";
    }

    char **parts;

    if (config_dir)
    {
        FILE *fp = fopen(config_dir, "w+");

        if (!fp)
        {
            perror("ERROR utils");
            exit(1);
        }

        parts = fileparts(props->finished_folder);
        sprintf(buffer, "finished_folder=%s%s\n", parts[1], parts[2]);
        fputs(buffer, fp);
        sprintf(buffer, "environment=%s\n", props->environment);
        fputs(buffer, fp);

        parts = fileparts(props->project_folder);
        sprintf(buffer, "project_folder=%s%s\n", parts[1], parts[2]);
        fputs(buffer, fp);

        fclose(fp);
    }else{
        config_dir = "";
        parts = fileparts(props->project_folder);
    }

    char **zip = fileparts(zip_dir);

    sprintf(buffer, "%s %s && zip -q -r %s%s %s && %s %s%s %s", cd, parts[0], zip[1], zip[2], parts[1], mov, zip[1], zip[2], zip_dir);

    if(strlen(config_dir) != 0 || strlen(functionFile) != 0){
        sprintf(buffer + strlen(buffer), " && %s %s && zip -q -j %s %s %s",cd, zip[0], zip_dir, config_dir, functionFile);
    }

    int status = system(buffer);

    return zip_dir;
}

void freeMatrix(char **matrix, int n)
{

    for (int j = 0; j < n; j++)
    {
        free(matrix[j]);
    }

    free(matrix);
}


/**
 * Upload project to the remote resources
 *
 * props - Structure that contains the tool configuration properties
 *
 */
void addProj(struct Properties* props)
{
    char *mainFolder = getMainFolder();
    char *curr = (char *)malloc((strlen(PROJ) + strlen(mainFolder) + 2) * sizeof(char));
    sprintf(curr, "%s%s", mainFolder, PROJ);

    FILE *fp = fopen(curr, "r");
    if (!fp)
    {
        char *cfg = (char *)malloc((strlen(CONFIG) + strlen(mainFolder) + 2) * sizeof(char));
        sprintf(cfg, "%s%s", mainFolder, CONFIG);

        char *proj_zip = (char *)malloc((strlen(ZIP) + strlen(mainFolder) + 2) * sizeof(char));
        sprintf(proj_zip, "%s%s", mainFolder, ZIP);

        char *zip_path = zip(props, NULL, cfg, proj_zip);

        char *res = upload(zip_path, props);

        FILE *fp = fopen(curr, "w+");
        if (!fp)
        {
            perror("ERROR custom");
            printf("\n\ncustom ->> %s\n\n", curr);
            exit(1);
        }

        fputs(res, fp);
        fclose(fp);

        free(cfg);
        free(proj_zip);
    }
    free(curr);
}
