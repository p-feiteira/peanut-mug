/* C file that is used to create the Octave's function next */
#include "mex.h"
#include "fetch.c"
#include "math.h"

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{

    struct Properties* props = getInstance();

    struct data result = fetch(props);

    plhs[0] = mxCreateDoubleScalar(result.idx);

    double temp;

    if(!strcmp(result.result, "Inf")){
        temp = INFINITY;
    }else{
        temp = strtod(result.result,NULL);
    }
    

    if (temp)
    {
        plhs[1] = mxCreateDoubleScalar(temp);
    }
    else
    {
        plhs[1] = mxCreateString(result.result);
    }
}