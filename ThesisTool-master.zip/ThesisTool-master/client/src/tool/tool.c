//
// Created by Pedro Feiteira on 27/03/2020.
//
#include "tool.h"
#include "queue.c"

pthread_mutex_t lock;
int start_Local = 1;

/**
 * Create the necessary folders for the tool to work
 *
 */
void createFolders()
{

    char *mainFolder = getMainFolder();

    char *dup = calloc(strlen(mainFolder) + 2, sizeof(char));

    strcpy(dup, mainFolder);

    char *dir = calloc(strlen(dup) + strlen("remote") + 3, sizeof(char));

    sprintf(dir, "%s%cremote%c", dup, FILE_SEPARATOR, FILE_SEPARATOR);

    make_directory(dir);

    free(dir);
    free(dup);
    free(mainFolder);
}

struct args
{
    int idx;
    char *command;
};

/**
 * Thread that exeutes the Octave's fragment, in local mode.
 *
 * arguments - structure that contains thread arguments
 *
 */
void *localThread(void *arguments)
{
    struct args *args = arguments;

    char result[50];

    FILE *fp = popen(args->command, "r");

    if (!fscanf(fp, "%s", result))
    {
        perror("ERROR fscanf");
        exit(1);
    }

    pclose(fp);

    pthread_mutex_lock(&lock);

    fp = fopen("temp.txt", "a+");

    if (!fp)
    {
        perror("mutex");
        exit(1);
    }

    char str[150];

    sprintf(str, "%d,%s\n", args->idx, result);

    fputs(str, fp);

    fclose(fp);

    pthread_mutex_unlock(&lock);

    return NULL;
}

/**
 * Functions that prepares the matrix received from the Octave to be executed by the tool, in local mode
 *
 * props - Structure that contains the tool configuration properties 
 * idx - Octave's request index
 * inSize - input size
 * matrix - Matrix received from Octave
 * size - matrix size
 *
 */
char *dynamicLocalExec(struct Properties *props, int idx, int inSize, char **matrix, int size)
{

    if (start_Local)
    {
        start_Local = 0;
        if (pthread_mutex_init(&lock, NULL) != 0)
        {
            printf("\n mutex init failed\n");
            exit(1);
        }
    }

    char *command = (char *)calloc(size + inSize + strlen("f = %s;fprintf(\'%%.35f\',f(") + strlen("))") + 100, sizeof(char));

    sprintf(command, "%s --eval \"addpath('%s');f = %s;fprintf(\'%%.35f\',f(", props->environment, props->project_folder, matrix[0]);

    for (int index = 1; index < inSize; index++)
    {
        if (index < inSize - 1)
        {
            sprintf(command + strlen(command), "%s,", matrix[index]);
        }
        else
        {
            sprintf(command + strlen(command), "%s", matrix[index]);
        }
    }

    char *outPtr = calloc(strlen(props->finished_folder) + 50, sizeof(char));

    sprintf(outPtr, "%s%coutput.txt", props->finished_folder, FILE_SEPARATOR);

    sprintf(command + strlen(command), "))\" 2> %s &", STDOUT);

    struct args *args = (struct args *)malloc(sizeof(struct args));

    args->command = command;
    args->idx = idx;

    pthread_t thread_id;
    pthread_create(&thread_id, NULL, localThread, (void *)args);
    pthread_join(thread_id, NULL);

    return outPtr;
}

// function [output,*] = funName(inputs,*)

/**
 * Functions that prepares the matrix received from the Octave to be executed by the tool, in remote mode
 *
 * inSize - input size
 * matrix - Matrix received from Octave
 * size - matrix size
 *
 */
char *directRemoteExec(int inSize, char **matrix, int size)
{
    char *result = (char *)calloc(size + inSize + strlen("f = %s;fprintf(\'%%.35f\',f(") + strlen("));") + 1, sizeof(char));
    sprintf(result, "f = %s;fprintf(\'%%.35f\',f(", matrix[0]);

    for (int index = 1; index < inSize; index++)
    {
        if (index < inSize - 1)
        {
            sprintf(result + strlen(result), "%s,", matrix[index]);
        }
        else
        {
            sprintf(result + strlen(result), "%s", matrix[index]);
        }
    }

    sprintf(result + strlen(result), "));");

    free(matrix);

    return result;
}