/* C file used to develop the Octave's cancel function, avaiable by the tool */

#include "mex.h"
#include "../http/operations.c"
#include "myFutures.c"

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
    struct Properties* props = getInstance();
    if (strstr(props->type, "local"))
    {
        //
    }
    else if (strstr(props->type, "remote"))
    {
        cancel(props);
    }
}