#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "queue.c"

struct Queue *queue;

/**
 * Reset the current queue
 *
 */
void resetQueue()
{
    queue = createQueue(1000);
}

/**
 * Add an element to the queue
 *
 * idx - Octave's fragment index
 * result - Octave's fragment result
 *
 */
void addToQueue(int idx, char *result)
{
    char *entryValue = calloc(strlen(result) + 1, sizeof(char));
    strcpy(entryValue, result);
    struct data newEntry = {.idx = idx, .result = entryValue};
    enqueue(queue, newEntry);
}

/**
 * Fill queue with the file results.
 *
 * props - Structure that contains the tool configuration properties
 *
 */
void fillQueue(struct Properties* props)
{
    FILE *fp = fopen("temp.txt", "r");

    if (!fp)
    {
        return;
    }
    else
    {
        queue = createQueue(1000);
        fseek(fp, 0, SEEK_END); // goto end of file
        if (ftell(fp) != 0)
        {
            fseek(fp, 0, SEEK_SET); // goto begin of file
            char buff[50];
            int idx;

            while (!feof(fp))
            {
                if (!fscanf(fp, "%d,%s\n", &idx, buff))
                {
                    printf("\n%s\n", buff);
                    perror("ERROR fscanf");
                    exit(1);
                }
                addToQueue(idx, buff);
            }
            fclose(fp);
            if (remove("temp.txt") != 0)
            {
                perror("remove");
                exit(1);
            }
        }
        else
        {
            fclose(fp);
        }
    }
}

/**
 * Return element from the queue
 *
 */
struct data getFromQueue()
{
    
    struct data result = dequeue(queue);

    return result;
}

/**
 * Verify if the queue is empty
 *
 */
int isQueueEmpty()
{
    if (queue == NULL)
    {
        queue = createQueue(1000);
    }
    return isEmpty(queue);
}