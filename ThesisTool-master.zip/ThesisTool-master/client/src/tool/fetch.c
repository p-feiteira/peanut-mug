#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include "../http/operations.c"
#include "./myFutures.c"

/**
 * Consumes the next ready element
 * 
 * props - Structure that contains the tool configuration properties
 *
 */
struct data fetch(struct Properties* props)
{
    if (strstr(props->type, "local"))
    {
        fillQueue(props);

        return getFromQueue(queue);
    }
    else if (strstr(props->type, "remote"))
    {
        char *body = fetchNext(props);
        char *token = strtok(body, "_");
        int index = atoi(token);
        token = strtok(NULL, "_");
        struct data next = {.idx = index, .result = token};
        return next;
    }
}