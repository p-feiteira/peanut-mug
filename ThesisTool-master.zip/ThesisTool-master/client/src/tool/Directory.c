#include "../headers/Directory.h"

/**
 * Get the tool absolute path  
 *
 */
char *getDirectory()
{

    int direct = 0;

    char *path = GetRealPath(".");

    char *result = calloc(strlen(path) + 1, sizeof(char));

    char *token = strtok(path, FILE_SEPARATOR_STR);

    if (token && !strcmp(token, "ThesisTool"))
    {
        direct = 1;
        if (!strcmp(OS, "unix"))
        {
            sprintf(result + strlen(result), "%c%s", FILE_SEPARATOR, token);
        }
        else
        {
            sprintf(result + strlen(result), "%s", token);
        }
    }

    else if (token)
    {
        if (!strcmp(OS, "unix"))
        {
            sprintf(result + strlen(result), "%c%s", FILE_SEPARATOR, token);
        }
        else
        {
            sprintf(result + strlen(result), "%s", token);
        }
    }
    else
    {
        perror("ERROR Directory");
        exit(1);
    }

    if (direct)
    {
        free(token);
        free(path);
        return result;
    }

    token = strtok(NULL, FILE_SEPARATOR_STR);

    while (token)
    {

        sprintf(result + strlen(result), "%c%s", FILE_SEPARATOR, token);

        if (!strcmp(token, "ThesisTool"))
        {
            break;
        }

        token = strtok(NULL, FILE_SEPARATOR_STR);
    }

    free(path);

    return result;
}

/**
 * Get tool's main folder absolute path 
 *
 */
char *getMainFolder()
{
    char *base_dir = getDirectory();

    char *result = calloc((strlen(base_dir) + 30), sizeof(char));
    sprintf(result, "%s%cclient%csrc%cmain", base_dir, FILE_SEPARATOR, FILE_SEPARATOR, FILE_SEPARATOR);

    free(base_dir);

    return result;
}