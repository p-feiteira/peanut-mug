#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#if _WIN32
#include <direct.h>
#define FILE_SEPARATOR '\\'
#define OS "windows"
#define EXT "bat"
#define USER_DIR getenv("USERPROFILE")
#define concatenate "type"
#define cpy "copy"
#define mov "move"
#define cd "cd /d"
#define make_directory(n) \
    {                     \
        mkdir(n);         \
    }
#else
#include <sys/stat.h>
#include <sys/types.h>
#define FILE_SEPARATOR '/'
#define OS "unix"
#define EXT "sh"
#define USER_DIR getenv("HOME")
#define concatenate "cat"
#define cpy "cp"
#define mov "mv"
#define cd "cd"
#define make_directory(n)  \
    {                      \
        mkdir(n, S_IRWXU); \
    }
#endif

#define PROPS_DIR "config.properties"
