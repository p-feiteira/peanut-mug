#include <stdio.h> /* defines FILENAME_MAX */
#include <stdlib.h>
#include <string.h>
//#define WINDOWS  /* uncomment this line to use it for windows.*/
#ifdef _WIN32
#include <windows.h>
#include <direct.h>
#include <conio.h>
#define GetCurrentDir _getcwd
#define FILE_SEPARATOR '\\'
#define FILE_SEPARATOR_STR "\\"
#define GetRealPath(p) _fullpath(NULL, p, _MAX_PATH);
    
#else
#include <unistd.h>
#define GetCurrentDir getcwd
#define FILE_SEPARATOR '/'
#define FILE_SEPARATOR_STR "/"
#define GetRealPath(p) realpath(p, NULL);
#endif