/* HTTP Client header */

#ifndef _SOCKET_H
#define _SOCKET_H
#include "../tool/configParser.c"

#if _WIN32
#include <winsock2.h>
#include <windows.h>
WSADATA wsa_data;

#define socket_start()                         \
    {                                          \
        WSAStartup(MAKEWORD(2, 0), &wsa_data); \
    }
#define socket_stop() \
    {                 \
        WSACleanup(); \
    }
#define bindSocket(s)                                                                         \
    {                                                                                         \
        int reuse = 1;                                                                        \
                                                                                              \
        if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof(reuse)) < 0) \
                                                                                              \
        {                                                                                     \
                                                                                              \
            perror("SO_REUSEADDR failed");                                                    \
                                                                                              \
            return -1;                                                                        \
        }                                                                                     \
    }
#define socket_close(s)       \
    {                         \
        shutdown(s, SD_BOTH); \
        closesocket(s);       \
    }
#define finish_send(s)        \
    {                         \
        shutdown(s, SD_SEND); \
    }
#define FILE_SEPARATOR '\\'
#else
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdarg.h>

#define socket_start()
#define socket_stop()
#define bindSocket(s)                                                                         \
    {                                                                                         \
        int reuse = 1;                                                                        \
                                                                                              \
        if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof(reuse)) < 0) \
                                                                                              \
        {                                                                                     \
                                                                                              \
            perror("SO_REUSEADDR failed");                                                    \
                                                                                              \
            return -1;                                                                        \
        }                                                                                     \
                                                                                              \
        if (setsockopt(s, SOL_SOCKET, SO_REUSEPORT, (const char *)&reuse, sizeof(reuse)) < 0) \
                                                                                              \
        {                                                                                     \
                                                                                              \
            perror("SO_REUSEPORT failed");                                                    \
                                                                                              \
            return -1;                                                                        \
        }                                                                                     \
    }
#define socket_close(s) \
    {                   \
        close(s);       \
        shutdown(s, 0); \
        shutdown(s, 1); \
        shutdown(s, 2); \
    }
#define finish_send(s)        \
    {                         \
        shutdown(s, SHUT_WR); \
    }
#define FILE_SEPARATOR '/'

#endif

#define SADDR struct sockaddr_in

#endif