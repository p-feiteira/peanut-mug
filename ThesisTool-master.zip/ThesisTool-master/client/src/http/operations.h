#include "client.c"
#include <time.h>
#define currentProject "/remote/currentProj.txt"
#define CLUSTER_DIR "cluster.properties"
#define EXECUTION_FILE "executions.txt"