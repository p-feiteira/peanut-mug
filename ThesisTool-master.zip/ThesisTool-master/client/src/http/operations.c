#include "operations.h"
#include <pthread.h>

char *curr_proj;

/**
 * Add request ID as an HTTP request's header
 *
 * header - HTTP request header
 * requestID - current ID in use
 *
 */
char *addRequestID(char *header, char *requestID)
{
    char temp[125];

    sprintf(temp, "requestID: %s\r\n", requestID);

    char *result = calloc(strlen(temp) + strlen(header) + 2, sizeof(char));

    strcpy(result, header);
    strcat(result, temp);

    return result;
}

/**
 * 
 * Creates the HTTP request with the necessary headers and send it to the remote proxy
 *
 * props - Structure that contains the tool configuration properties
 * function - Octave fragment that will be send
 * idx - Octave fragment's index, used to order the HTTP responses
 *
 */
void sendFunction(struct Properties *props, char *function, int idx)
{
    int server = start(props->ip, props->port);

    char header[1024];
    sprintf(header, "Host: %s:%d\r\nenv: %s\r\nContent-Type: text/plain\r\nContent-Length: %lu\r\nidx: %d\r\n", props->ip, props->port, props->environment, strlen(function), idx);

    if (curr_proj == NULL)
    {
        char *mainFolder = getMainFolder();

        char *proj_path = (char *)malloc((strlen(mainFolder) + strlen(currentProject) + 4) * sizeof(char));

        sprintf(proj_path, "%s%s", mainFolder, currentProject);

        FILE *proj = fopen(proj_path, "r");
        if (proj)
        {
            char buf[100];
            if (!fgets(buf, 100, proj))
            {
                perror("ERROR fgets");
                exit(1);
            }
            sprintf(header + strlen(header), "requestID: %s\r\n", buf);
            curr_proj = calloc(strlen(buf) + 1, sizeof(char));
            strcpy(curr_proj, buf);
            fclose(proj);
            free(proj_path);
        }
    }
    else
    {
        sprintf(header + strlen(header), "requestID: %s\r\n", curr_proj);
    }

    char *buffer;
    buffer = buildHeader("POST", "sendFunction", header);
    buffer = insertFunctionOnBody(buffer, function);

    sendDataByIndex(server, buffer);
    parseBody(server);
}

/**
 * Uploads the project that will be used to the remote resources.
 * So, it is not necessary send project's information in each HTTP request.
 * This happens before the first HTTP request.
 *
 * path - Project's absolute path
 * props - Structure that contains the tool configuration properties
 * 
 */
char *upload(const char *path, struct Properties *props)
{
    int server = start(props->ip, props->port);
    char base_header[512];
    sprintf(base_header, "Accept: text/plain\r\nHost: %s:%d\r\nContent-Type: application/zip\r\n", props->ip, props->port);
    char *buffer = buildHeader("POST", "upload", base_header);

    sendData(server, buffer, path, "rb");

    free(buffer);

    char *body = parseBody(server);

    return body;
}

/**
 * Fetch the next Octave fragment that is ready to be consumed.
 *
 * props - Structure that contains the tool configuration properties
 */

char *fetchNext(struct Properties *props)
{
    int server = start(props->ip, props->port);
    char base_header[512];
    sprintf(base_header, "Accept: text/plain\r\nHost: %s:%d\r\n", props->ip, props->port);
    char *buffer = buildHeader("GET", "fetchNext", base_header);

    sendData(server, buffer, NULL, "rb");

    free(buffer);

    char *body = parseBody(server);

    return body;
}

/**
 * Used to flush the Octave fragments that can be discarded 
 *
 * props - Structure that contains the tool configuration properties
 *
 */
void cancel(struct Properties *props)
{
    int server = start(props->ip, props->port);
    char base_header[100];
    sprintf(base_header, "Host: %s:%d\r\n", props->ip, props->port);
    char *buffer = buildHeader("GET", "cancel", base_header);

    sendData(server, buffer, NULL, "rb");
    parseBody(server);
    free(buffer);
}

/**
 * Send the service(s) configuration to the proxy (simple server discovery)
 * props - Structure that contains the tool configuration properties
 * cfg_path - Configuration file absolute path
 *
 */
char *config(struct Properties *props, char *cfg_path)
{

    char base[1024];
    int server = start(props->ip, props->port);
    sprintf(base, "Accept: text/plain\r\nHost: %s:%d\r\nContent-Type: text/plain\r\n", props->ip, props->port);

    char *buffer = buildHeader("POST", "config", base);

    sendData(server, buffer, cfg_path, "rb");

    free(buffer);

    char *body = parseBody(server);

    return body;
}

/**
 * Turn off the tool remote resources
 *
 * props - Structure that contains the tool configuration properties
 *
 */
char *turnOff(struct Properties props)
{
    char base[1024];
    int server = start(props.ip, props.port);
    sprintf(base, "Accept: text/plain\r\nHost: %s:%d\r\n", props.ip, props.port);

    char *buffer = buildHeader("GET", "shutdown", base);

    sendData(server, buffer, NULL, "rb");

    free(buffer);

    char *body = parseBody(server);

    return body;
}