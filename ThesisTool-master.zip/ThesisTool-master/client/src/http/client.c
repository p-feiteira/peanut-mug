#include "client.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>

// /status/{pid}

struct Headers
{
    long content_length;
    char *filename;
    char *transfer_encoding;
};

int hexadecimalToDecimal(char hexVal[])
{
    int len = strlen(hexVal);

    // Initializing base value to 1, i.e 16^0
    int base = 1;

    int dec_val = 0;

    // Extracting characters as digits from last character
    for (int i = len - 1; i >= 0; i--)
    {
        // if character lies in '0'-'9', converting
        // it to integral 0-9 by subtracting 48 from
        // ASCII value.
        if (hexVal[i] >= '0' && hexVal[i] <= '9')
        {
            dec_val += (hexVal[i] - 48) * base;

            // incrementing base by power
            base = base * 16;
        }

        // if character lies in 'A'-'F' , converting
        // it to integral 10 - 15 by subtracting 55
        // from ASCII value
        else if (hexVal[i] >= 'A' && hexVal[i] <= 'F')
        {
            dec_val += (hexVal[i] - 55) * base;

            // incrementing base by power
            base = base * 16;
        }
    }

    return dec_val;
}

char *copyStr(char *src, int length)
{
    char *result = calloc(length + 1, sizeof(char));
    int i;

    for (i = 0; i < length; i++)
    {
        result[i] = src[i];
    }

    result[i] = '\0';

    return result;
}


/**
    Build HTTP header.

    method - HTTP Method
    url - url for HTTP request
    headers - HTTP request headers
 */ 
char *buildHeader(const char *method, const char *url, char *headers)
{
    char *result = calloc(strlen(method) + strlen(url) + strlen(headers) + 50, sizeof(char));
    sprintf(result, "%s /server/%s HTTP/1.1\r\n%s", method, url, headers);
    return result;
}


/**
 * Create an internet address.
 *   
 * ip - Destination IP
 * port - Destination port
 *
*/
SADDR getAddress(const char *ip, const int port)
{
    SADDR addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = inet_addr(ip),
        .sin_port = htons(port)};
    return addr;
}

/**
 * Initialize and create the socket that will be used in HTTP request. 
 *
 * ip - Destination IP
 * port - Destination port
*/
int start(const char *ip, const int port)
{
    socket_start();
    SADDR host = getAddress(ip, port);
    int server = socket(AF_INET, SOCK_STREAM, 0);

    if (server < 0)
    {
        printf("\n%s, %d\n", ip, port);
        perror("Socket Error!");
        socket_stop();
        return -1;
    }

    bindSocket(server);

    struct sockaddr_in client = {0};

    client.sin_family = AF_INET;

    client.sin_addr.s_addr = inet_addr("0.0.0.0");

    client.sin_port = htons(0);

    if (bind(server, (struct sockaddr *)&client, sizeof(client)) < 0)
    {

        perror("bind failed");

        return -1;
    }

    if (connect(server, (struct sockaddr *)&host, sizeof host) != 0)
    {
        printf("Connect Error!");
        socket_stop();
        return -1;
    }

    return server;
}

long getFileSize(FILE *file)
{
    fseek(file, 0, SEEK_END); // seek to end of file
    long size = ftell(file);  // get current file pointer
    //printf("%ld\n", size);
    fseek(file, 0, SEEK_SET); // seek back to beginning of file
    return size;
}


/**
 * Insert the Octave fragment inside the HTTP request's body
 *
 * header - current HTTP header
 * function - Octave fragment
 *
*/
char *insertFunctionOnBody(char *header, char *function)
{

    char *result = calloc(strlen(header) + 2 + strlen(function) + 1, sizeof(char));

    strcpy(result, header);
    strcat(result, "\r\n");
    strcat(result, function);

    return result;
}


/**
 * Send the HTTP request that contains the Octave fragment
 *
 * server - socket descriptor
 * buff - HTTP request
 *
*/
int sendDataByIndex(const int server, char *buff)
{
    int status = -2;

    if ((status = send(server, buff, strlen(buff), 0)) < 0)
    {
        printf("Send Error!");
        socket_stop();
        return status;
    }
    finish_send(server);
    return status;
}

/**
 * Send the HTTP request that contains the Octave fragment
 *
 * server - socket descriptor
 * buff - HTTP request
 * path - file path, if exists
 * mode - file descriptor mode (rb or wb)
 *
*/
int sendData(const int server, char *buff, const char *path, char *mode)
{
    FILE *fp;
    int hasFile = -1;
    int status = -2;
    char *toSend;

    if ((fp = fopen(path, mode)) != NULL)
    {
        hasFile = 1;
        long size = getFileSize(fp);
        toSend = calloc(strlen(buff) + 50, sizeof(char));
        sprintf(toSend, "%sContent-Length: %lu\r\n\r\n", buff, size);
    }
    else
    {
        hasFile = 0;
        toSend = calloc(strlen(buff) + 4, sizeof(char));
        sprintf(toSend, "%s\r\n", buff);
    }

    if ((status = send(server, toSend, strlen(toSend), 0)) < 0)
    {
        printf("Send Error!");
        socket_stop();
        return status;
    }

    if (hasFile == 1)
    {
        char file[200];
        int b;

        while (!feof(fp))
        {
            b = fread(file, 1, sizeof(file), fp);
            status = send(server, file, b, 0);
        }
        fclose(fp);
    }

    finish_send(server);
    return status;
}


/**
 * Parse HTTP response header
 *
 * server - socket descriptor
 *
*/
struct Headers parseHeader(const int server)
{
    char buff[1024] = "", *ptr = buff + 4;
    int bytes_received;
    struct Headers result = {.content_length = -1, .filename = NULL, .transfer_encoding = NULL};
    while ((bytes_received = recv(server, ptr, 1, 0)))
    {
        if (bytes_received == -1)
        {
            perror("Parse Header");
            exit(1);
        }

        if (
            (ptr[-3] == '\r') && (ptr[-2] == '\n') &&
            (ptr[-1] == '\r') && (*ptr == '\n'))
            break;
        ptr++;
    }

    *ptr = 0;
    ptr = buff + 4;

    char *temp;

    if (bytes_received)
    {
        ptr = strtok(ptr, "\r\n");
        while (ptr != NULL)
        {
            if ((temp = strstr(ptr, "Content-Length:")))
            {
                sscanf(temp, "%*s %ld", &result.content_length);
            }
            else if ((temp = strstr(ptr, "filename = ")))
            {
                result.content_length = 1;
                char *token = strtok(temp, " = ");
                token = strtok(NULL, " = ");
                result.filename = calloc(strlen(token) + 2, sizeof(char));
                strcpy(result.filename, token);
            }
            else if ((temp = strstr(ptr, "chunked")))
            {
                result.transfer_encoding = "chunked";
            }
            ptr = strtok(NULL, "\r\n");
        }
    }
    return result;
}

/**
 * Read HTTP response status
 *
 * server - socket descriptor
 *
 */
int readHttpStatus(const int server)
{
    char buff[1024] = "", *ptr = buff + 1;
    int bytes_received, status;
    //printf("Begin Response ..\n");
    while ((bytes_received = recv(server, ptr, 1, 0)))
    {
        if (bytes_received == -1)
        {
            perror("ReadHttpStatus");
            exit(1);
        }

        if ((ptr[-1] == '\r') && (*ptr == '\n'))
            break;
        ptr++;
    }
    *ptr = 0;
    ptr = buff + 1;

    sscanf(ptr, "%*s %d ", &status);

    return (bytes_received > 0) ? status : 0;
}

/**
 * Parse HTTP response body data
 *
 * server - socket descritor
 * size - body length (from Content-length header)
 *
 */
char *receiveData(const int server, int size)
{
    char buff[size], *ptr = buff + 1;
    int bytes_received, status;
    int counter = 0;
    
    while ((bytes_received = recv(server, ptr, 1, 0)))
    {
        if (bytes_received == -1)
        {
            perror("receivedData");
            exit(1);
        }
        ptr++;
        counter++;

        if (counter == size)
            break;
    }
    *ptr = 0;
    ptr = buff + 1;

    char *result = calloc(strlen(ptr) + 2, sizeof(char));
    strcpy(result, ptr);

    return result;
}

/**
 * Parse HTTP response body
 *
 * server - socket descriptor
 *
*/
char *parseBody(const int server)
{

    int bytes_received;
    char recv_data[1024];

    char *result = "NOT FINISHED YET";

    int status = readHttpStatus(server);

    if (status == 204)
        return result;

    struct Headers header = parseHeader(server);

    int size = header.content_length;

    if (status && size)
    {
        if (header.filename != NULL)
        {
            int offset = 0;
            size = 1024;
            char temp[20];
            char *data_ptr = recv_data;

            if (strstr(header.transfer_encoding, "chunked"))
            {

                while ((bytes_received = recv(server, data_ptr, 1, 0)))
                {
                    if ((data_ptr[-1] == '\r') && (*data_ptr == '\n'))
                    {
                        size = hexadecimalToDecimal(temp);
                        break;
                    }
                    temp[offset] = data_ptr[0];
                    offset++;
                    data_ptr++;
                }
            }
            int bytes = 0;
            char *mainFolder = getMainFolder();
            char *downloadPath = calloc(strlen(mainFolder) + 100, sizeof(char));
            sprintf(downloadPath, "%s%cremote%c%s", mainFolder, FILE_SEPARATOR, FILE_SEPARATOR, header.filename);
            FILE *fd = fopen(downloadPath, "wb");

            while ((bytes_received = recv(server, recv_data, size, 0)))
            {
                if (bytes_received == -1)
                {
                    perror("receive");
                    exit(3);
                }

                fwrite(recv_data, 1, size, fd);
                bytes += bytes_received;
                
                if (bytes == size)
                    break;
            }
            fclose(fd);
            result = downloadPath;
        }
        else
        {
            result = receiveData(server, size);
        }
    }

    socket_close(server);

    return result;
}