delete("*.mex");
mkoctfile --mex -lws2_32 -lrpcrt4 -lpthread ..\\tool\\executionTool.c
mkoctfile --mex -lws2_32 -lrpcrt4 -lpthread ..\\tool\\next.c
mkoctfile --mex -lws2_32 ..\\tool\\cancel.c