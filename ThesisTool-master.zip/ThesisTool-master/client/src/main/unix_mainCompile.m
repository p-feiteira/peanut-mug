delete("*.mex");
mkoctfile --mex -pthread ../tool/executionTool.c
mkoctfile --mex -pthread ../tool/next.c
mkoctfile --mex ../tool/cancel.c