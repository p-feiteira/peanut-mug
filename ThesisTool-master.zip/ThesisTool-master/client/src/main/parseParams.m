function [paramParse] = parseParams(params)

#disp("In parseParams");

fields = fieldnames(params);

#disp("Fields");
#disp(fields);

paramParse = struct();

for i = 1:length(params)
    #disp("Value");
    value = strcat("str2func(\'", getfield(params(i),fields{1,1}), "\')");
    #disp("First value");
    #disp(value);
    paramParse = setfield(paramParse,{i},fields{1,1},value);
    #disp(paramParse);
    #disp("fields length");
    #disp(length(fields));
    for j = 2:length(fields)
        value = getfield(params(i),fields{j,1});
        #disp(value);
        if isa(value,'char')
            value = strcat("\'", value, "\'");
        elseif isa(value, 'function_handle')
            str = func2str(value);
            value = strcat("str2func(\'", str, "\')");
        else
            str = mat2str(value);
            value = str;
        endif
        paramParse = setfield(paramParse,{i},fields{j,1},value);
    end
end
##disp("ParamParse");
##disp(paramParse);
clearvars fields value params;
end