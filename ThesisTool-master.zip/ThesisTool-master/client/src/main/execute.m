function [] = execute(idx, varargin)

in = {};
%disp("PARSE");
%tic;
for i=1:length(varargin)

    value = varargin{i};
    if isa(value, 'char')
        value = strcat("\'", value, "\'");
    elseif isa(value, 'function_handle')
        str = func2str(value);
        value = strcat("str2func(\'", str, "\')");
    else
        %disp(value);
        %disp(idx);
        str = mat2str(value, 35);
        %disp(str);
        value = str;
    end
    in{i} = value;
end
%toc;
%disp("TOOL");
%tic;
executionTool(idx, in);
%toc;
end
