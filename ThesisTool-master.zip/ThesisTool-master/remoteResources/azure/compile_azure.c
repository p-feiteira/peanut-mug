#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("\n\nWrong number of arguments. Insert the Operating System of your machine, windows/unix!\n\n");
        exit(1);
    }

    if (!strcmp(argv[1], "windows"))
    {
        system("rm .\\clean_azure.exe .\\prepare_azure.exe .\\shutdown_azure.exe");
        system("gcc -o .\\clean_azure.exe .\\clean_azure.c");
        system("gcc -o .\\prepare_azure.exe .\\prepare_azure.c");
        system("gcc -o .\\shutdown_azure.exe .\\shutdown_azure.c");
    }
    else if (!strcmp(argv[1], "unix"))
    {
        system("rm ./clean_azure.o ./prepare_azure.o ./shutdown_azure.o");
        system("gcc -o ./clean_azure.o ./clean_azure.c");
        system("gcc -o ./prepare_azure.o ./prepare_azure.c");
        system("gcc -o ./shutdown_azure.o ./shutdown_azure.c");
    }
    else
    {
        printf("\n\nERROR on inserted Operating System\n\n");
        printf("\n\nTry again!\n\n");
        exit(1);
    }

    printf("\n\nDone\n\n");

    return 0;
}