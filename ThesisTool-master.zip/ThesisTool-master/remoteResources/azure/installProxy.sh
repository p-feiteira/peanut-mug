#! /bin/bash

# exit if a command fails
set -e

sudo apt-get update
sudo apt-get install -y software-properties-common
sudo apt-get install -y zip unzip
sudo apt install -y openjdk-11-jre-headless
sudo apt install -y build-essential
sudo apt install -y openssh-server
sudo apt-get remove -y software-properties-common

cd
mkdir remote