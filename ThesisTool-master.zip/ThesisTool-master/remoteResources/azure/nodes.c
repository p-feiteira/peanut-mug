#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define NODES_CONFIG "./nodes.properties"

struct Remote_info
{
    char REMOTE_FILE_SEPARATOR;
    char *REMOTE_EXT;
    char *REMOTE_MOV;
    char *REMOTE_CPY;
    char *REMOTE_USER;
};

struct node_info
{
    char *type;
    int ssh_port;
    int port;
    char* size;
    int cpus;
    char *os;
    char *location;
};

struct nodes
{
    struct node_info *services;
    int size;
};

struct Remote_info fill_OS_info(const char *remoteOS)
{

    struct Remote_info info;

    if (strstr(remoteOS, "unix"))
    {

        info.REMOTE_FILE_SEPARATOR = '/';
        info.REMOTE_EXT = "sh";
        info.REMOTE_MOV = "mv";
        info.REMOTE_CPY = "cp";
        info.REMOTE_USER = "~";
    }
    else
    {
        info.REMOTE_FILE_SEPARATOR = '\\';
        info.REMOTE_EXT = "bat";
        info.REMOTE_MOV = "move";
        info.REMOTE_CPY = "copy";
        info.REMOTE_USER = "\%USERPROFILE\%";
    }

    return info;
}

struct nodes readNodes()
{
    struct nodes nodes;
    FILE *fp = fopen(NODES_CONFIG, "r");

    if (!fp)
    {
        perror("ERROR readRemote");
        printf("\npath ->>> %s\n\n", NODES_CONFIG);
    }

    char buff[255];
    char *token;
    char *key;
    char *value;

    int currentSize = 10;
    nodes.services = malloc(currentSize * sizeof(struct node_info));
    int counter = -1;

    while (!feof(fp))
    {
        if(!fgets(buff, 255, fp)){
            continue;
        }

        if (strstr(buff, "#"))
        {
            continue;
        }

        if (counter + 1 == currentSize)
        {
            struct nodes_info *temp = malloc(currentSize * sizeof(struct node_info));
            memcpy(temp, nodes.services, currentSize * sizeof(struct node_info));
            free(nodes.services);
            currentSize = 1.5 * currentSize;
            nodes.services = malloc(currentSize * sizeof(struct node_info));
            memcpy(nodes.services, temp, (currentSize / 1.5) * sizeof(struct node_info));
            free(temp);
            counter++;
        }

        char *type = NULL;

        if (strstr(buff, "[Proxy]"))
        {
            type = "proxy";
        }
        else if (strstr(buff, "[Node]"))
        {
            type = "node";
        }

        if (type != NULL)
        {
            ++counter;
            nodes.services[counter].type = calloc(strlen(type) + 1, sizeof(char));
            strcpy(nodes.services[counter].type, type);
            continue;
        }

        token = strtok(buff, "\n");
        key = strtok(token, "=");
        value = strtok(NULL, "=");

        if (!strcmp(key, "ssh_port"))
        {
            nodes.services[counter].ssh_port = atoi(strtok(value, "\r"));
        }
        else if (!strcmp(key, "port"))
        {
            nodes.services[counter].port = atoi(strtok(value, "\r"));
        }
        else if (!strcmp(key, "size"))
        {
            nodes.services[counter].size = calloc(strlen(value) + 1, sizeof(char));
            strcpy(nodes.services[counter].size, strtok(value, "\r"));
        }
        else if (!strcmp(key, "cpus"))
        {
            nodes.services[counter].cpus = atoi(strtok(value, "\r"));
        }
        else if (!strcmp(key, "os"))
        {
            nodes.services[counter].os = calloc(strlen(value) + 1, sizeof(char));
            strcpy(nodes.services[counter].os, strtok(value, "\r"));
        }
        else if (!strcmp(key, "location"))
        {
            nodes.services[counter].location = calloc(strlen(value) + 1, sizeof(char));
            strcpy(nodes.services[counter].location, strtok(value, "\r"));
        }
    }
    nodes.size = counter + 1;
    return nodes;
}