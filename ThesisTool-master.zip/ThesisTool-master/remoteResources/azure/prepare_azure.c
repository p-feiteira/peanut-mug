#include <stdio.h>
#include <stdlib.h>
#include "nodes.c"

//remote double quotes character from the string
char *processJSONValue(char *value)
{
    char *result = calloc(strlen(value) + 2, sizeof(char));
    int counter = 0;
    for (int i = 0; i < strlen(value); i++)
    {
        if (value[i] == '"')
        {
            continue;
        }
        if (value[i] == ',')
        {
            return result;
        }
        else
        {
            result[counter] = value[i];
            counter++;
        }
    }
    return result;
}

char *getVM_IP(char *name, char *key)
{
    char *result;

    char *path = calloc(strlen(name) + 200, sizeof(char));

    sprintf(path, "vm_info%s.json", name);

    FILE *fp = fopen(path, "r+");
    if (!fp)
    {
        perror("ERROR start");
        free(path);
        exit(1);
    }
    else
    {
        char buffer[200];
        while (!feof(fp))
        {
            if (!fgets(buffer, 256, fp))
            {
                continue;
            }
            if (strstr(buffer, key))
            {
                char *token = strtok(buffer, ": ");
                token = strtok(NULL, ": ");
                char *ip = processJSONValue(token);
                result = calloc(20 + strlen(ip) + strlen(name), sizeof(char));
                sprintf(result, "azure%s@%s", name, ip);
                return result;
            }
        }
        free(path);
        return NULL;
    }
}

int main(int argc, char **argv)
{

    struct nodes serviceNodes = readNodes();

    char cmd[500];
    char result[500];

    int proxy = 0;

    sprintf(cmd, "az login");
    system(cmd);
    sprintf(cmd, "az group create --name myResourceGroup --location %s", serviceNodes.services[0].location);
    system(cmd);

    char *vmName;

    FILE *vmNames = fopen("vmNames.txt", "w+");

    for (int i = 0; i < serviceNodes.size; i++)
    {
        struct node_info currentNode = serviceNodes.services[i];
        vmName = calloc(strlen(currentNode.type) + 20, sizeof(char));
        sprintf(vmName, "%s%d", currentNode.type, currentNode.port);
        fputs(vmName, vmNames);

        if (i + 1 < serviceNodes.size)
        {
            fputs("\n", vmNames);
        }

        char path[200];
        char *address;

        sprintf(path, "vm_info%s.json", vmName);
        FILE *test = fopen(path, "r+");
        if (!test)
        {
            if (!strcmp(currentNode.os, "unix"))
            {
                sprintf(cmd, "az vm create --resource-group myResourceGroup --name %s --location %s --image UbuntuLTS --size %s --admin-username azure%s > vm_info%s.json", vmName, currentNode.location, currentNode.size, vmName, vmName);
            }
            else if (!strcmp(currentNode.os, "windows"))
            {
                printf("\nInstallation of C, Octave, Java and zip, for Windows VMs, are not supported. The user MUST install them, manually.\n");
                sprintf(cmd, "az vm create --resource-group myResourceGroup --name %s --location %s --image win2016datacenter --size %s --admin-username azure%s > vm_info%s.json", vmName, currentNode.location, currentNode.size, vmName, vmName);
            }
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            sprintf(cmd, "az network nsg create --resource-group myResourceGroup --location %s --name myNetworkSecurityGroup%s", currentNode.location, vmName);
            printf("\n\n%s\n\n", cmd);

            system(cmd);

            sprintf(cmd, "az network nsg rule create --resource-group myResourceGroup --nsg-name myNetworkSecurityGroup%s --name %sRule --protocol tcp --priority 330 --access allow --destination-port-ranges %d", vmName, vmName, currentNode.port);
            printf("\n\n%s\n\n", cmd);

            system(cmd);

            sprintf(cmd, "az network nsg rule create --resource-group myResourceGroup --nsg-name myNetworkSecurityGroup%s --name default-allow-ssh --protocol tcp --priority 1000 --access allow --destination-port-ranges 22", vmName);
            printf("\n\n%s\n\n", cmd);

            system(cmd);

            sprintf(cmd, "az network nic update --resource-group myResourceGroup --name %sVMNic --network-security-group myNetworkSecurityGroup%s", vmName, vmName);
            printf("\n\n%s\n\n", cmd);

            system(cmd);

            address = getVM_IP(vmName, "publicIpAddress");

            sprintf(cmd, "ssh -p %d %s \"echo test\"", currentNode.ssh_port, address);
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            if (!strcmp(currentNode.os, "windows"))
            {
                sprintf(cmd, "ssh -p %d %s \"mkdir remote\"", currentNode.ssh_port, address);
                printf("\n\n%s\n\n", cmd);

                system(cmd);
                if (!strcmp(serviceNodes.services[i].type, "proxy"))
                {
                    proxy = 1;
                    sprintf(cmd, "(scp -P %d ..\\..\\zips\\proxy.zip %s:%%USERPROFILE%%\\remote\\service.zip) && ", currentNode.ssh_port, address);
                }
                else
                {
                    proxy = 0;
                    sprintf(cmd, "(scp -P %d ..\\..\\zips\\service.zip %s:%%USERPROFILE%%\\remote\\service.zip) && ", currentNode.ssh_port, address);
                }
                sprintf(cmd + strlen(cmd), "(ssh -p %d %s \"cd /D %%USERPROFILE%%\\remote\\ && unzip service.zip\")", currentNode.ssh_port, address);
            }

            else if (!strcmp(currentNode.os, "unix"))
            {
                if (!strcmp(serviceNodes.services[i].type, "proxy"))
                {
                    proxy = 1;
                    sprintf(cmd, "(scp -P %d installProxy.sh %s:~/installProxy.sh) && (ssh -p %d %s \"chmod a+x installProxy.sh && ./installProxy.sh\") && (scp -P %d ../../zips/proxy.zip %s:~/remote/service.zip) && ", currentNode.ssh_port, address, currentNode.ssh_port, address, currentNode.ssh_port, address);
                }
                else
                {
                    proxy = 0;
                    sprintf(cmd, "(scp -P %d installService.sh %s:~/installService.sh) && (ssh -p %d %s \"chmod a+x installService.sh && ./installService.sh\") && (scp -P %d ../../zips/service.zip %s:~/remote/service.zip) && ", currentNode.ssh_port, address, currentNode.ssh_port, address, currentNode.ssh_port, address);
                }
                sprintf(cmd + strlen(cmd), "(ssh -p %d %s \"cd ~/remote/ && unzip service.zip\")", currentNode.ssh_port, address);
            }
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }
        else
        {
            fclose(test);
            sprintf(cmd, "az vm start --resource-group MyResourceGroup --name %s && sleep 30", vmName);
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            sprintf(cmd, "az network nic update --resource-group myResourceGroup --name %sVMNic --network-security-group myNetworkSecurityGroup%s", vmName, vmName);
            printf("\n\n%s\n\n", cmd);

            system(cmd);

            sprintf(cmd, "az vm list-ip-addresses --resource-group MyResourceGroup --name %s > vm_info%s.json", vmName, vmName);
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            address = getVM_IP(vmName, "ipAddress");

            sprintf(cmd, "ssh -p %d %s \"echo test\"", currentNode.ssh_port, address);
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            if (!strcmp(serviceNodes.services[i].type, "proxy"))
            {
                proxy = 1;
            }
            else
            {
                proxy = 0;
            }
        }

        char *ip = calloc(strlen(address) + 2, sizeof(char));
        strcpy(ip, address);
        ip = strtok(ip, "@");
        ip = strtok(NULL, "@");

        if (!strcmp(currentNode.os, "windows"))
        {
            printf("\nAfter the manually installation of C, Octave and Java insert:\n\nssh -p %d %s \"java -jar %%USERPROFILE%%\\remote\\service\\webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d < NUL > NUL 2>&1\" &\n\nAt a command prompt.", currentNode.ssh_port, address, currentNode.port);
        }
        else if (!strcmp(currentNode.os, "unix"))
        {
            sprintf(cmd, "ssh -p %d %s \"java -jar ~/remote/service/webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d < /dev/null > /dev/null 2>&1 &\"", currentNode.ssh_port, address, currentNode.port);
            printf("\n%s\n", cmd);
            system(cmd);
        }

        if (!proxy)
        {
            sprintf(result + strlen(result), "%s:%d:%d\n", ip, currentNode.port, currentNode.cpus);
        }
        else
        {
            printf("\n\n\nProxy IP -> %s with port %d\n\n\n", ip, currentNode.port);
        }
    }

    FILE *hosts = fopen("../../hosts.txt", "w+");

    fputs(result, hosts);

    fclose(hosts);

    printf("\n\nServices successfully started!\n\n");

    return 0;
}