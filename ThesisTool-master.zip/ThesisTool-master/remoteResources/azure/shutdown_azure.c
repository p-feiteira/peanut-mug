#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{

    FILE *fp = fopen("vmNames.txt", "r");

    if (!fp)
    {
        perror("ERROR");
        exit(1);
    }

    char buff[250];
    char cmd[500];

    while (!feof(fp))
    {
        if(!fgets(buff, 250, fp)){
            continue;
        }

        char *temp = calloc(strlen(buff) + 1, sizeof(char));
        strcpy(temp, buff);

        temp = strtok(temp, "\n");
        sprintf(cmd, "az vm stop --name %s --resource-group myResourceGroup & az vm deallocate --name %s --resource-group myResourceGroup &", temp, temp);
        system(cmd);
    }
    return 0;
}