#include <stdio.h>
#include <stdlib.h>
#include "Properties.c"

int main(int argc, char **argv)
{

    if (argc < 2)
    {
        printf("\n\nWrong number of arguments. Should have the proxy address.\n\n");
        printf("Proxy address is the docker swarm's leader node (insert \"docker node ls\" at terminal to find it)\n\n\n");
        exit(1);
    }

    struct Remote_Properties props = readRemoteProperties("remote.properties");

    FILE *fp = fopen("../../hosts.txt", "r");

    if (!fp)
    {
        perror("ERROR:");
        printf("\nMissing the hosts.txt file! Execute first the reservation\n\n");
        exit(1);
    }

    char cmd[500];

    char *temp = calloc(strlen(props.host) + 1, sizeof(char));
    strcpy(temp, props.host);
    temp = strtok(temp, "@");

    char *proxyHost = calloc(strlen(props.host) + 1, sizeof(char));
    sprintf(proxyHost, "%s@%s", temp, argv[1]);

    if (!strcmp(props.host_OS, "unix"))
    {
        if (!props.hasService)
        {
            sprintf(cmd, "ssh -p %d %s \"mkdir remote\"", props.ssh_port, props.host);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            sprintf(cmd, "scp -P %d %s %s:%s", props.ssh_port, "../../zips/proxy.zip", props.host, "~/remote/proxy.zip");
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            sprintf(cmd, "scp -P %d %s %s:%s", props.ssh_port, "./service/serv.tar", props.host, "~/remote/serv.tar");
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }

        char current[30];
        while (!feof(fp))
        {
            if(!fgets(current, 30, fp)){
            continue;
        }
            char *node = calloc(strlen(temp) + strlen(current) + 1, sizeof(char));
            char* token = strtok(current, ":");
            sprintf(node, "%s@%s", temp, token);

            sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'echo %s\'\"", props.ssh_port, props.host, node, node);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            //sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'docker images serv | wc -l\'\" > temp.txt", props.ssh_port, props.host, node);
            //printf("\n\n%s\n\n", cmd);
            //system(cmd);
            sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'cd ~/remote/ && docker load --input serv.tar &&", props.ssh_port, props.host, node);
            token = strtok(NULL, ":");
            sprintf(cmd + strlen(cmd)," docker run -d -p %d:8001 serv &\'\"", atoi(token));
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            free(node);
        }

        fclose(fp);

        if (!props.hasService)
        {
            sprintf(cmd, "ssh -T -p %d %s \"cd ~/remote/ && unzip proxy.zip && rm proxy.zip\"", props.ssh_port, props.host);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }

        sprintf(cmd, "ssh -t -L %d:%s:%d -p %d %s \"ssh %s \'java -jar ~/remote/service/webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d & echo $!\'\"", props.port, argv[1], props.port, props.ssh_port, props.host, proxyHost, props.port);
    }
    else
    {
        if (!props.hasService)
        {
            sprintf(cmd, "ssh -p %d %s \"mkdir remote\"", props.ssh_port, props.host);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            sprintf(cmd, "scp -P %d %s %s:%s", props.ssh_port, "..\\..\\zips\\proxy.zip", props.host, "%%USERPROFILE%%\\remote\\proxy.zip");
            printf("\n\n%s\n\n", cmd);
            system(cmd);

            sprintf(cmd, "scp -P %d %s %s:%s", props.ssh_port, ".\\service\\serv.tar", props.host, "%%USERPROFILE%%\\remote\\serv.tar");
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }

        char current[30];
        while (!feof(fp))
        {
            fgets(current, 30, fp);
            char *node = calloc(strlen(temp) + strlen(current) + 1, sizeof(char));
            char* token = strtok(current, ":");
            sprintf(node, "%s@%s", temp, token);
            sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'echo %s\'", props.ssh_port, props.host, node, node);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
            //sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'docker images serv | wc -l\'\" > temp.txt", props.ssh_port, props.host, node);
            //printf("\n\n%s\n\n", cmd);
            //system(cmd);
            //FILE *fp2 = fopen("temp.txt", "r");
            //char buffer[10];
            //fgets(buffer, 10, fp2);
            //if (1)
            //{
            //    sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'cd %%USERPROFILE%%\\remote\\ && docker load --input serv.tar\'\"", props.ssh_port, props.host, node);
            //    printf("\n\n%s\n\n", cmd);
            //    system(cmd);
            //}
            //fclose(fp2);
            sprintf(cmd, "ssh -t -p %d %s \"ssh %s \'cd %%USERPROFILE%%\\remote\\ && docker load --input serv.tar &&", props.ssh_port, props.host, node);
            token = strtok(NULL, ":");
            sprintf(cmd + strlen(cmd), " docker run -d -p %d:8001 serv &\'\"", atoi(token));
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }
        fclose(fp);

        if (!props.hasService)
        {
            sprintf(cmd, "ssh -p %d %s \"cd %%USERPROFILE%%\\remote\\ && unzip proxy.zip && rm proxy.zip\"", props.ssh_port, props.host);
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }

        sprintf(cmd, "ssh -t -L %d:%s:%d -p %d %s \"ssh %s \'java -jar %%USERPROFILE%%\\remote\\service\\webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d\'\"", props.port, argv[1], props.port, props.ssh_port, props.host, proxyHost, props.port);
    }

    printf("\n\n%s\n\n", cmd);

    system(cmd);

    return 0;
}