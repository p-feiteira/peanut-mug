#include <stdio.h>
#include "Properties.c"
#define PORT 10000

int main(int argc, char **argv)
{

    //mode -> docker ; ssh
    //user@ip

    char hosts[200];
    char temp;
    struct Remote_Properties props = readRemoteProperties("remote.properties");

    printf("\nStarting cluster's nodes reservation: (Press Enter to continue at each step)\n");
    scanf("%c", &temp);
    printf("\n1-Open a terminal (search \"cmd\" on Windows or \"terminal\" on Unix Systems)\n");
    scanf("%c", &temp);
    printf("\n2-Insert the command:\n\nssh -p %d %s\n", props.ssh_port, props.host);
    scanf("%c", &temp);
    printf("\nIs it the first cluster usage?\n(yes/no)\n\n");
    char res[5];
    scanf("%s", res);
    if (!strcmp(res, "yes"))
    {
        char *username = calloc(strlen(props.host) + 1, sizeof(char));
        strcpy(username, props.host);
        printf("\n1-Inside the SSH shell, insert the command:\n\necho -e \"\\n\" | ssh-keygen -t rsa -q -f \"/home/%s/.ssh/id_rsa\" -N \"\"\n\n", strtok(username, "@"));
        scanf("%c", &temp);
        printf("\n2-Inside the SSH shell, insert the command:\n\ncat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys\n\n");
        scanf("%c", &temp);
    }
    printf("\n3-Inside the SSH shell, insert the reservation command, changing X value to the needed values:\n\n");
    printf("If it is a specific reservation use the command:\n\n\t\toarsub -I -l /cluster=X/nodes=X/core=X\n\n");
    printf("If it is a simple reservation use the command:\n\n\t\toarsub -I -l nodes=X\n\n");
    printf("More options at cluster's wiki.\n\n");
    scanf("%c", &temp);
    printf("\n4-After the reservation, insert the command:\n\noarprint host\n");
    scanf("%c", &temp);

    printf("\n5-Insert the result of the previous command here, separated by commas (notice that the first one will be the proxy):\n\n");
    scanf("%s", hosts);
    printf("\n\nInserted: %s\n\n", hosts);

    FILE *fp = fopen("../../hosts.txt", "w+");

    if (!fp)
    {
        perror("ERROR");
    }

    char *token = calloc(strlen(hosts) + 1, sizeof(char));
    strcpy(token, hosts);

    token = strtok(token, ",");
    token = strtok(NULL, ",");

    char *curr;

    int counter = 0;

    printf("\n6-Insert the number of cores for each one of the inserted nodes:\n\n");

    while (token != NULL)
    {
        curr = calloc(strlen(token) + 20, sizeof(char));
        int cpu;
        printf("For %s:\n",token);
        printf("Number of cores: \n");
        if(scanf(" %d", &cpu) <= 0){
            perror("SCANF\n\n");
        }
        printf("\n");
        sprintf(curr, "%s:%d:%d", token, PORT + counter, cpu);
        fputs(curr, fp);

        token = strtok(NULL, ",");
        if (token != NULL)
        {
            fputs("\n", fp);
        }
        free(curr);
        counter++;
    }

    fclose(fp);

    printf("7-Let the terminal open please.\n\n");
    return 0;
}