#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{

    FILE *info_fp = fopen("machines.txt", "r+");
    FILE *pids_fp = fopen("pids.txt", "r+");

    if (!info_fp || !pids_fp)
    {
        perror("ERROR");
        exit(1);
    }

    char buff[50];
    char pid[20];
    char cmd[300];


    while (!feof(info_fp) && !feof(pids_fp))
    {
        if(!fgets(buff, 50, info_fp)){
            continue;
        }
        printf("%s", buff);
        if(!fgets(pid, 20, pids_fp)){
            continue;
        }
        char *temp = calloc(strlen(buff) + 1, sizeof(char));
        if (buff[strlen(buff) - 1] == '\n')
        {
            strncpy(temp, buff, strlen(buff) - 1);
        }
        else
        {
            strcpy(temp, buff);
        }
        temp = strtok(temp, ":");
        sprintf(cmd, "ssh -p %d %s \"kill %d\"", atoi(temp), strtok(NULL, ":"), atoi(pid));
        printf("\n%s\n", cmd);
        system(cmd);
        free(temp);
    }

    fclose(info_fp);
    fclose(pids_fp);

    remove("machines.txt");
    remove("pids.txt");

    printf("\nResources successfully stopped!\n\n");

    return 0;
}