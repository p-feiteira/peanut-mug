#include <stdio.h>
#include <string.h>
#include "nodes.c"
#include "../../client/src/headers/OS_header.h"

int main(int argc, char **argv)
{
    FILE *machines = fopen("machines.txt", "w+");

    struct nodes serviceNodes = readNodes();
    char result[500] = "\0";
    int proxy = 0;
    for (int i = 0; i < serviceNodes.size; i++)
    {
        char *currentHost = serviceNodes.services[i].host;
        int ssh_port = serviceNodes.services[i].ssh_port;
        int port = serviceNodes.services[i].port;
        int cpus = serviceNodes.services[i].cpus;
        char *host_os = serviceNodes.services[i].os;
        fprintf(machines, "%d:%s\n", ssh_port, currentHost);
        char *token = calloc(strlen(currentHost) + 1, sizeof(char));
        strcpy(token, currentHost);
        token = strtok(token, "@");
        char *address = calloc(strlen(token) + 1, sizeof(char));
        strcpy(address, token);
        token = strtok(NULL, "@");
        char *ip = calloc(strlen(token) + 1, sizeof(char));
        strcpy(ip, token);

        char cmd[800];
        if (!serviceNodes.services[i].hasService)
        {
            if (!strcmp(host_os, "windows"))
            {
                printf("\nInstallation of C, Octave, Java and zip, for Windows VMs, are not supported. The user MUST install them, manually.\n");
                sprintf(cmd, "ssh -t -p %d %s \"mkdir remote\"", ssh_port, currentHost);
                printf("\n\n%s\n\n", cmd);
                system(cmd);

                if (!strcmp(serviceNodes.services[i].type, "proxy"))
                {
                    proxy = 1;
                    sprintf(cmd, "(scp -P %d ..\\..\\zips\\proxy.zip %s:%%USERPROFILE%%\\remote\\service.zip) && ", ssh_port, currentHost);
                }
                else
                {
                    proxy = 0;
                    sprintf(cmd, "(scp -P %d ..\\..\\zips\\service.zip %s:%%USERPROFILE%%\\remote\\service.zip) &&", ssh_port, currentHost);
                }
                sprintf(cmd + strlen(cmd), "(ssh -t -p %d %s \"cd /D %%USERPROFILE%%\\remote\\ && unzip service.zip\")", ssh_port, currentHost);
            }

            else if (!strcmp(host_os, "unix"))
            {
                if (!strcmp(serviceNodes.services[i].type, "proxy"))
                {
                    proxy = 1;
                    sprintf(cmd, "(scp -P %d installProxy.sh %s:~/installProxy.sh) && (ssh -t -p %d %s \"chmod a+x installProxy.sh && ./installProxy.sh\") && (scp -P %d ../../zips/proxy.zip %s:~/remote/service.zip) && ", ssh_port, currentHost, ssh_port, currentHost, ssh_port, currentHost);
                }
                else
                {
                    proxy = 0;
                    sprintf(cmd, "(scp -P %d installService.sh %s:~/installService.sh) && (ssh -t -p %d %s \"chmod a+x installService.sh && ./installService.sh\") && (scp -P %d ../../zips/service.zip %s:~/remote/service.zip) && ", ssh_port, currentHost, ssh_port, currentHost, ssh_port, currentHost);
                }
                sprintf(cmd + strlen(cmd), "(ssh -t -p %d %s \"cd ~/remote/ && unzip service.zip\")", ssh_port, currentHost);
            }
            printf("\n\n%s\n\n", cmd);
            system(cmd);
        }

        if (!strcmp(host_os, "windows"))
        {
            printf("\nAfter the manually installation of C, Octave and Java insert:\n\nssh -t -p %d %s \"java -jar %%USERPROFILE%%\\remote\\service\\webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d < NUL > NUL 2>&1\" &\n\nAt a command prompt.", ssh_port, currentHost, port);
        }
        else if (!strcmp(host_os, "unix"))
        {
            sprintf(cmd, "ssh -p %d %s \"java -jar ~/remote/service/webservice-1.0-SNAPSHOT.jar 0.0.0.0 %d < /dev/null > /dev/null 2>&1 & echo $!\" >> pids.txt", ssh_port, currentHost, port);
            printf("\n%s\n", cmd);
            system(cmd);
        }

        if (proxy)
        {
            sprintf(result + strlen(result), "%s:%d:%d\n", ip, port, cpus);
        }
        else
        {
            printf("\n\nProxy IP -> %s with port %d\n\n", ip, port);
        }
    }
    fclose(machines);

    FILE *hosts = fopen("../../hosts.txt", "w+");

    fputs(result, hosts);

    fclose(hosts);

    printf("\n\nServices successfully started!\n\n");

    return 0;
}