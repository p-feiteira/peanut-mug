#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("\n\nWrong number of arguments. Insert the Operating System of your machine, windows/unix!\n\n");
        exit(1);
    }

    if (!strcmp(argv[1], "windows"))
    {
        system("rm .\\prepare_hosts.exe .\\shutdown_hosts.exe");
        system("gcc -o .\\prepare_hosts.exe .\\prepare_hosts.c");
        system("gcc -o .\\shutdown_hosts.exe .\\shutdown_hosts.c");
    }
    else if (!strcmp(argv[1], "unix"))
    {
        system("rm ./prepare_hosts.o ./shutdown_hosts.o");
        system("gcc -o ./prepare_hosts.o ./prepare_hosts.c");
        system("gcc -o ./shutdown_hosts.o ./shutdown_hosts.c");
    }
    else
    {
        printf("\n\nERROR on inserted Operating System\n\n");
        printf("\n\nTry again!\n\n");
        exit(1);
    }

    printf("\n\nDone\n\n");

    return 0;
}