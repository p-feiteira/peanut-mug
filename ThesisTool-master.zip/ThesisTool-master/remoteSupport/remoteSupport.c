#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "../client/src/tool/utils.c"
#include "zlib.h"
#define STATIC_ZIP "/static.zip"

#define HOSTS_TXT "hosts.txt"

struct timeval s, e;

char *getEnvironment(char *env)
{
    //TODO

    char *result;

    char *workspace = getDirectory();

    char *dir = (char *)malloc((strlen(workspace) + strlen("env.properties") + 50) * sizeof(char));
    sprintf(dir, "%s%cclient%csrc%ctool%c%s", workspace, FILE_SEPARATOR, FILE_SEPARATOR, FILE_SEPARATOR, FILE_SEPARATOR, "env.properties");

    FILE *fp = fopen(dir, "r");

    if (!fp)
    {
        perror("ERROR getEnv");
        printf("dir ->>> %s\n\n\n", dir);
    }

    char buffer[255];

    while (!feof(fp))
    {

        if(!fgets(buffer, 255, fp)){
            continue;
        }

        if (strstr(buffer, env))
        {
            char *token = strtok(buffer, "=");
            token = strtok(NULL, "=");
            token = strtok(token, "\n");
            result = (char *)malloc((strlen(token) + 2) * sizeof(char));
            strcpy(result, token);
            break;
        }
    }

    fclose(fp);
    free(dir);
    free(workspace);

    return result;
}

char *http_static(const char *path, struct Properties props, char *cmd)
{

    int server = start(props.ip, props.port);
    char base_header[512];
    sprintf(base_header, "Accept: text/plain\r\nHost: %s:%d\r\nContent-Type: application/zip\r\ncmd: %s\r\n", props.ip, props.port, cmd);
    char *buffer = buildHeader("POST", "static", base_header);

    sendData(server, buffer, path, "rb");

    return parseBody(server);
}

char *static_status(char *reqID, struct Properties props)
{
    char base[1024];
    //To remove the idx

    char *temp = calloc((strlen(reqID) + 1), sizeof(char));
    strcpy(temp, reqID);

    char *token = strtok(temp, "_");
    char *req = token;
    //printf("\n\nreq -> %s\n\n", req);
    token = strtok(NULL, "_");
    long pid = atol(token);
    //printf("\n\npid -> %ld\n\n", pid);

    int server = start(props.ip, props.port);
    sprintf(base, "Accept: text/plain\r\nHost: %s:%d\r\nrequestID: %s\r\npid: %ld\r\n\r\n", props.ip, props.port, req, pid);
    char *buffer = buildHeader("GET", "staticResult", base);

    sendDataByIndex(server, buffer);

    //printf("reqID -> %s", reqID);

    //printf("buffer ->>> %lu\n\n", strlen(buffer));

    char *body = parseBody(server);
    //printf("\n\n body ->> %s\n\n", body);

    return body;
}

char *remoteStatic(char **argv, struct Properties props)
{
    char *currDir = getDirectory();

    char *env = getEnvironment(props.environment);

    char *path = calloc(strlen(currDir) + 30, sizeof(char));

    sprintf(path, "%s%cstatic%cremoteStatic.txt", currDir, FILE_SEPARATOR, FILE_SEPARATOR);

    FILE *fp = fopen(path, "w+");

    if (!fp)
    {
        perror("ERROR remoteStatic");
        printf("path ->>> %s\n\n", path);
    }

    char buff[512];

    sprintf(buff, "%s", env);

    char *current;
    int index = 1;

    while ((current = argv[index]) != NULL)
    {
        sprintf(buff + strlen(buff), " %s", current);
        index++;
    }

    fputs(buff, fp);

    fclose(fp);

    return path;
}

char *processCMD(char **argv)
{
    char *result = calloc(512, sizeof(char));
    char *current;
    int index = 1;

    while ((current = argv[index]) != NULL)
    {
        sprintf(result + strlen(result), " %s", current);
        index++;
    }

    return result;
}

int main(int argc, char **argv)
{

    if (argc < 2)
    {
        printf("Insert the main file and the arguments to execute the project");
        exit(1);
    }

    struct Properties props = getProperties();

    char *dir = getDirectory();
    char hosts_p[strlen(HOSTS_TXT) + strlen(dir) + 2];
    sprintf(hosts_p, "%s%c%s", dir, FILE_SEPARATOR, HOSTS_TXT);

    config(props, hosts_p);

    char *zip_directory = (char *)malloc((strlen(getDirectory()) + strlen(STATIC_ZIP) + 10) * sizeof(char));
    sprintf(zip_directory, "%s%cremoteSupport%s", getDirectory(), FILE_SEPARATOR, STATIC_ZIP);

    char *zip_path = zip(props, NULL, NULL, zip_directory);

    //printf("zip_path -> %s\n\n", zip_path);
    gettimeofday(&s, NULL);
    char *body = http_static(zip_path, props, processCMD(argv));
    gettimeofday(&e, NULL);     
    printf("\nCOMPUTATION RESULT:\n\n%s\n\n", body);
    long seconds = (e.tv_sec - s.tv_sec);
    long micros = ((seconds * 1000000) + e.tv_usec) - (s.tv_usec);
    printf("Time elapsed is %d seconds and %d micros\n", seconds, micros);
    free(zip_directory);

    return 0;
}