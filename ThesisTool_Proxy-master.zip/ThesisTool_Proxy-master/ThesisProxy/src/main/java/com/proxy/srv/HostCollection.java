package com.proxy.srv;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;

public class HostCollection implements Serializable {

	private static final long serialVersionUID = 1L;
	private String proxyID;
    private List<Host> hosts;
    private volatile AtomicInteger integer;

    public HostCollection() {
        this.hosts =   Collections.synchronizedList(new ArrayList<>());
        this.proxyID = "";
        this.integer = new AtomicInteger(0);
    }

    public void add(WebTarget target, String requestID) {
        Host h = new Host(target, requestID);
        this.hosts.add(h);
    }

    public Host get(int index) {
        return this.hosts.get(index);
    }

    public Host getNext() {
        int keySize = hosts.size();
        return this.hosts.get(integer.getAndIncrement() % keySize);
    }

    public String getProxyID() {
        return this.proxyID;
    }

    public void setProxyID(String proxyID) {
    	System.out.println(proxyID);
        this.proxyID = proxyID;
    }

    public int size() {
        return this.hosts.size();
    }

    public void store() {
        try {

            FileOutputStream fos = new FileOutputStream("clients.tmp");
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            Map<String, String> temp = new HashMap<>();

            hosts.forEach(e -> {
                temp.put(e.getTarget().getUri().toString(), e.getRequestID());
            });

            oos.writeObject(temp);
            oos.close();
            fos.close();

            fos = new FileOutputStream("reqId.tmp");
            oos = new ObjectOutputStream(fos);

            oos.writeBytes(proxyID);
            oos.close();
            fos.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();

        }
    }

    @SuppressWarnings("unchecked")
    public void load() {
        try {

            FileInputStream fis = new FileInputStream("clients.tmp");
            ObjectInputStream ois = new ObjectInputStream(fis);
            Map<String, String> temp = (Map<String, String>) ois.readObject();
            ois.close();
            fis.close();

            this.hosts = Collections.synchronizedList(new ArrayList<Host>());

            temp.forEach((k, v) -> {
                Client client = ClientBuilder.newClient();
                hosts.add(new Host(client.target(k), v));
            });

            fis = new FileInputStream("reqId.tmp");
            ois = new ObjectInputStream(fis);
            proxyID = new String(ois.readAllBytes());
            System.out.println(proxyID);
            ois.close();
            fis.close();

        } catch (FileNotFoundException e) {
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
