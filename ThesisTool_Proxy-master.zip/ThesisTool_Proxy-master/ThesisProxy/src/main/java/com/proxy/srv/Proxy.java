package com.proxy.srv;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class Proxy {

	@POST
	@Path("config")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response manageResources(byte[] file) {
		return ProxyClient.config(new String(file));
	}

	@POST
	@Path("upload")
	@Consumes("application/zip")
	@Produces(MediaType.TEXT_PLAIN)
	public Response upload(byte[] content) {
		return ProxyClient.upload(content);
	}

	@POST
	@Path("static")
	@Consumes("application/zip")
	@Produces(MediaType.TEXT_PLAIN)
	public Response httpStatic(byte[] content, @HeaderParam("cmd") String cmd) {
		return ProxyClient.execute(content, cmd);
	}

	@POST
	@Path("sendFunction")
	@Consumes(MediaType.TEXT_PLAIN)
	public Response sendFunction(@HeaderParam("requestID") String requestID, String function,
			@HeaderParam("env") String env, @HeaderParam("idx") int idx) {
		return ProxyClient.send(requestID, function, env, idx);
	}

	@GET
	@Path("fetchNext")
	@Produces(MediaType.TEXT_PLAIN)
	public Response fetchNext() {
		return ProxyClient.fetchNext();
	}

	@GET
	@Path("cancel")
	public void cancel() {
		ProxyClient.cancel();
	}

}
