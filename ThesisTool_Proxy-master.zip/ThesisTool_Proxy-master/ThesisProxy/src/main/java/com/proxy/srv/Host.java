package com.proxy.srv;

import jakarta.ws.rs.client.WebTarget;
import java.io.Serializable;

public class Host implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private WebTarget target;
	private String requestID;
	
	public Host(WebTarget target, String requestID) {
		this.target = target;
		this.requestID = requestID;
	}
	
	public WebTarget getTarget() {
		return this.target;
	}
	
	public String getRequestID() {
		return this.requestID;
	}

}
