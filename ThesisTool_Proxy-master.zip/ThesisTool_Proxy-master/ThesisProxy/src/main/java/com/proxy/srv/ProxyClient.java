package com.proxy.srv;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.proxy.srv.FuturesSingleton.FuturesQueue;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class ProxyClient {

	private static final int TCP_PORT = 9999;

	private static List<WebTarget> clients;
	private static volatile FuturesQueue queue = FuturesSingleton.getInstance().getQueue();
	private static volatile HostCollection currentCollection = new HostCollection();

	protected static Response config(String fileContent) {

		clients = new ArrayList<WebTarget>();

		String[] lines = fileContent.split("\n");

		for (String line : lines) {
			Client client = ClientBuilder.newClient();
			String host = line.split("\r")[0];
			String[] parts = host.split(":");
			WebTarget target = client.target("http://" + parts[0] + ":" + parts[1] + "/server/");
			clients.add(target);
			target.path("config").request().header("threads", parts[2]).header("port", TCP_PORT).get();
			queue.setTargets(clients);
		}
		
		clients.forEach(k -> {
			System.out.println("new host -> " + k.getUri());
		});
		
		System.out.println(clients.size());

		return Response.ok("Configuration Ready").type(MediaType.TEXT_PLAIN).build();

	}

	protected static Response upload(byte[] content) {

		UUID proxyUuid = UUID.randomUUID();

		clients.forEach((e) -> {

			String requestID = e.path("upload").request().accept(MediaType.TEXT_PLAIN)
					.post(Entity.entity(content, "application/zip")).readEntity(String.class);


			System.out.println(requestID);

			currentCollection.add(e, requestID);

		});

		currentCollection.setProxyID(proxyUuid.toString());
		currentCollection.store();

		return Response.ok(proxyUuid.toString()).type(MediaType.TEXT_PLAIN).build();
	}

	protected static Response execute(byte[] content, String cmd) {

		Random rand = new Random();
		Response result = clients.get(rand.nextInt(clients.size())).path("static").request()
				.accept(MediaType.TEXT_PLAIN).header("cmd", cmd).post(Entity.entity(content, "application/zip"));

		String toSend = result.readEntity(String.class);

		System.out.println(toSend);

		byte[] bytes = toSend.getBytes(StandardCharsets.UTF_8);

		String utf8EncodedString = new String(bytes, StandardCharsets.UTF_8);
		
		return Response.ok(utf8EncodedString).header("Content-Length", utf8EncodedString.length()).type(MediaType.TEXT_PLAIN).build();
	}

	protected static Response send(String requestID, String function, String env, long idx) {

		if (currentCollection.size() == 0) {
			currentCollection.load();
		}

		Host h = currentCollection.getNext();
		WebTarget target = h.getTarget();
		String reqID = h.getRequestID();

		queue.add(idx, target, reqID, env, function);
		return Response.ok().build();
	}

	protected static Response fetchNext() {
		StructureEntry next = queue.next();
		return Response.ok(next.getIdx() + "_" + next.getResult(), MediaType.TEXT_PLAIN).build();
	}

	protected static void cancel() {
		System.out.println("Cleaning all queue entries");
		queue.cancel();
	}

}
