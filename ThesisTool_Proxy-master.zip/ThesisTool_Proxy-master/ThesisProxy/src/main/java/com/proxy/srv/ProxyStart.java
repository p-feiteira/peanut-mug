package com.proxy.srv;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import sun.misc.Signal;
import sun.misc.SignalHandler;

import java.io.IOException;
import java.net.URI;

public class ProxyStart {

	// Base URI the Grizzly HTTP server will listen on
	public static final String BASE_URI = "http://%s:%d/server/";

	/**
	 * Starts Grizzly HTTP server exposing JAX-RS resources defined in this
	 * application.
	 * 
	 * @return Grizzly HTTP server.
	 */
	public static HttpServer startServer(String ip, int port) {
		// create a resource config that scans for JAX-RS resources and providers
		// in com.example package
		final ResourceConfig rc = new ResourceConfig().packages("com");

		// create and start a new instance of grizzly http server
		// exposing the Jersey application at BASE_URI
		String uri = String.format(BASE_URI, ip, port);
		return GrizzlyHttpServerFactory.createHttpServer(URI.create(uri), rc);
	}

	/**
	 * Main method.
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		if (args.length < 2) {
			System.err.println("\nMissing ip, port and mode arguments!\n");
			System.err.println("The command should be:\nmvn exec:java -Dexec.args=\"<ip> <port>\"\n");
			System.exit(-1);
		}

		String ip = args[0];
		int port = Integer.parseInt(args[1]);
		HostFileSingleton.getInstance();
		final HttpServer server = startServer(ip, port);
		System.out.println(String.format("Jersey app started with WADL available at " + "%s\nHit enter to stop it...",
				String.format(BASE_URI, ip, port)));
		
		final long start = System.nanoTime();

		Signal.handle(new Signal("INT"), new SignalHandler() {
			public void handle(Signal sig) {
				System.out.format("\nProgram execution took %f seconds\n", (System.nanoTime() - start) / 1e9f);
				server.shutdown();
				System.exit(0);
			}
		});
	}
}
