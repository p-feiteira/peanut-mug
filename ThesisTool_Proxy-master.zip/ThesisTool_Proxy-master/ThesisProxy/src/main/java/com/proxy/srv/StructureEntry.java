package com.proxy.srv;

public class StructureEntry {
    private long currentStep;
    private long idx;
    private String requestID;
    private long pid;
    private String result;

    public StructureEntry(){}

    public void setCurrentStep(long currentStep) {
        this.currentStep = currentStep;
    }

    public void setIdx(long idx) {
        this.idx = idx;
    }

    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public long getCurrentStep() {
        return currentStep;
    }

    public long getIdx() {
        return idx;
    }

    public String getRequestID() {
        return requestID;
    }

    public long getPid() {
        return pid;
    }

    public String getResult() {
        return result;
    }
    
    @Override
    public String toString() {
    	return idx + " , " + result;
    }
}
