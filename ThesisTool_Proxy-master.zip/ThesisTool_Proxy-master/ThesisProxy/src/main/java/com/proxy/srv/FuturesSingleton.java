package com.proxy.srv;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

import com.google.gson.Gson;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

public class FuturesSingleton {

	private static volatile FuturesSingleton instance;
	private static volatile FuturesQueue queue;

	private FuturesSingleton() {
		queue = new FuturesQueue();
	}

	public FuturesQueue getQueue() {
		return queue;
	}

	public static FuturesSingleton getInstance() {
		if (instance == null) {
			synchronized (FuturesSingleton.class) {
				if (instance == null) {
					instance = new FuturesSingleton();
				}
			}
		}
		return instance;
	}

	public static class FuturesQueue {

		private BlockingQueue<StructureEntry> queue;
		private List<WebTarget> targets;
		private AtomicLong currentTimeStep;

		public FuturesQueue() {
			init();
			new TCPServer();
		}

		public void add(long idx, WebTarget target, String reqID, String env, String function) {

			target.path("sendFunction").request().header("requestID", reqID).header("currentStep", currentTimeStep)
					.header("idx", idx).header("env", env).post(Entity.entity(function, MediaType.TEXT_PLAIN));
		}

		public StructureEntry next() {
			StructureEntry result = null;

			while (true) {
				if (queue.isEmpty()) {
					continue;
				}
				try {
					result = queue.poll();
					if (result.getCurrentStep() >= currentTimeStep.get()) {
						// System.out.println(result.getCurrentStep() + " >= " + currentTimeStep.get());
						break;
					} else {
						// System.out.println(result.getCurrentStep() + " < " + currentTimeStep.get());
					}
				} finally {
					// System.out.println("Queue size _> " + queue.size());
				}
			}
			// System.out.println(result);
			return result;
		}

		public class TCPServer {

			private static final int TCP_PORT = 9999;

			private ServerSocket serverSocket;

			public TCPServer() {
				Thread serverMainThread = new Thread(() -> {
					try {
						serverSocket = new ServerSocket();
						serverSocket.setReuseAddress(true);
						serverSocket.bind(new InetSocketAddress("0.0.0.0", TCP_PORT));
						System.out.println("TCP Server Listening at ip " + "0.0.0.0" + " port 9999");

						while (true) {
							Socket clientSocket = serverSocket.accept();
							new Thread(new ClientHandler(clientSocket)).start();
						}

					} catch (IOException e) {
						stop();
					}
				});
				serverMainThread.setDaemon(true);
				serverMainThread.start();
			}

			public void stop() {
				try {
					serverSocket.close();
				} catch (IOException e) {
				}
			}

		}

		protected class ClientHandler implements Runnable {
			private final Socket clientSocket;

			public ClientHandler(Socket socket) {
				this.clientSocket = socket;
			}

			public void run() {

				BufferedReader in = null;

				try {
					in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
					String inputLine;
					while ((inputLine = in.readLine()) != null) {
						System.out.println("New entry arrived!");
						StructureEntry entry = new Gson().fromJson(inputLine, StructureEntry.class);
						queue.add(entry);
					}
				} catch (IOException e) {
				} finally {
					try {
						if (in != null) {
							in.close();
							clientSocket.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}

		public class Task implements Runnable {

			private WebTarget target;
			private String reqID;
			private long idx;
			private String env;
			private String function;

			public Task(WebTarget target, String reqID, long idx, String env, String function) {
				this.target = target;
				this.reqID = reqID;
				this.idx = idx;
				this.env = env;
				this.function = function;
			}

			@Override
			public void run() {
				target.path("sendFunction").request().header("requestID", reqID).header("currentStep", currentTimeStep)
						.header("idx", idx).header("env", env).post(Entity.entity(function, MediaType.TEXT_PLAIN));
			}
		}

		public void cancel() {
			synchronized (this) {
				this.currentTimeStep.incrementAndGet();
				targets.forEach(t -> {
					t.path("reset").request().header("step", this.currentTimeStep.get()).get().getStatus();
				});
			}
		}

		public void setTargets(List<WebTarget> targets) {
			this.targets = targets;
		}

		private void init() {
			this.queue = new ArrayBlockingQueue<StructureEntry>(1000);
			this.currentTimeStep = new AtomicLong(1L);
		}
	}
}
