package com.proxy.srv;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class HostFileSingleton {
    private static volatile HostFileSingleton instance;
    private static volatile HostsFileManagement management;
    
    private HostFileSingleton() {
        management = new HostsFileManagement();
    }

    public HostsFileManagement getManagement(){
        return management;
    }

    public static HostFileSingleton getInstance() {
        if (instance == null) {
            synchronized (HostFileSingleton.class) {
                if (instance == null) {
                    instance = new HostFileSingleton();
                }
            }
        }
        return instance;
    }
    
    public static class HostsFileManagement implements Serializable {

    	private static final long serialVersionUID = 1L;
    	private static List<String> hostsList;
    	private static AtomicInteger counter = new AtomicInteger();

    	public HostsFileManagement() {
    		hostsList = new ArrayList<String>();
    	}

    	public void add(String host) {
    		hostsList.add(host);
    	}

    	public void remove(String host) {
    		hostsList.remove(host);
    	}

    	public boolean contains(String host) {
    		return hostsList.contains(host);
    	}

    	public List<String> getList() {
    		return hostsList;
    	}

    	public void setNodes(byte[] content) {

    		if (!hostsList.isEmpty()) {
    			return;
    		}
    		String fileContent = new String(content);
    		String[] lines = fileContent.split("\n");
    		for (String line : lines) {
    			hostsList.add(line.split("\r")[0]);
    		}

    		hostsList.forEach(k -> {
    			System.out.println("new host -> " + k);
    		});

    	}

    	public String getNode() {

    		int keySize = hostsList.size();

    		int i = counter.updateAndGet(n -> n % keySize);

    		return hostsList.get(i);
    	}

    }
    
}
