package com.srv.res;

import com.srv.res.common.ProcessStructure;
import jakarta.ws.rs.core.Response;

public class Reset {

	public static Response reset(long newValue) {
		ProcessStructure.getInstance(-1, null,-1).structure.reset(newValue);
		return Response.ok().build();
	}

}
