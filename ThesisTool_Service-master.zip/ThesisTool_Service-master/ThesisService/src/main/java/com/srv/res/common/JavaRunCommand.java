package com.srv.res.common;

import java.io.*;

public class JavaRunCommand {

	public static String systemRun(String directory, boolean isSync, String... command) {
		StringBuilder result = new StringBuilder();
		try {
			ProcessBuilder builder = new ProcessBuilder();
			builder.command(command);
			builder.directory(new File(directory));
			Process process = builder.start();

			InputStream is = process.getInputStream();

			BufferedReader reader = new BufferedReader(new InputStreamReader(is));

			String line;
			try {
				while ((line = reader.readLine()) != null) {
					result.append(line);
					result.append("\n");

				}
				result.append("\n");
				reader.close();
			} catch (IOException e1) {
			}

			return result.toString();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return null;
	}
}
