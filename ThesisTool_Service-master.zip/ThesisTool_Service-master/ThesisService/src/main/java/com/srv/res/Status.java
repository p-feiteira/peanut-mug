package com.srv.res;

import java.io.*;
import java.util.Properties;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.srv.res.common.Utils.*;

public class Status {

	public static Response status(final String requestID, final long pid, final String functionID) {

		final String folder = String.format(REQ_DIR, requestID);

		final File f = new File(folder);

		if (!f.exists())
			return Response.serverError().build();

		Properties props = null;
		String outputFolder = "";
		if (!requestID.equals("default")) {
			props = loadConfig(getFile(folder, "properties"));
			outputFolder = File.separator + props.getProperty("finished_folder") + File.separator;
		}

		while (true) {
			try {
				if (ProcessHandle.of(pid).isPresent()) {
					continue;
				} else {
					final String outputFile;
					if (functionID != null)
						outputFile = String.format(folder + "%s%s.txt", outputFolder, functionID);
					else
						outputFile = String.format(folder + "%sresult.txt", outputFolder);
					
					File file = new File(outputFile);
					
					if(file.length() == 0) {
						continue;
					}
					
					final BufferedReader reader = new BufferedReader(new FileReader(file));
					final StringBuilder response = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						response.append(line);
					}
					response.append("\n");
					System.out.println(functionID + ":" + response.toString());
					reader.close();
					return Response.ok(response.toString()).type(MediaType.TEXT_PLAIN).build();
				}
			} catch (final FileNotFoundException e) {
				return Response.status(404).build();
			} catch (final IOException e) {
				return Response.serverError().build();
			}
		}
	}
}
