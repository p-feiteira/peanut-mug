package com.srv;

import org.glassfish.grizzly.http.server.Request;

import com.srv.res.*;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/")
public class Resources {

    @GET
    @Path("start")
    @Produces(MediaType.TEXT_PLAIN)
    public Response start() {
        return Response.ok("Running!").type(MediaType.TEXT_PLAIN).build();
    }

    @GET
    @Path("config")
    public Response config(@Context Request request,@HeaderParam("threads") int threads, @HeaderParam("port") int port) {
    	String ip = request.getRemoteAddr();
        return Config.config(threads, ip, port);
    }

    @POST
    @Path("upload")
    @Consumes("application/zip")
    @Produces(MediaType.TEXT_PLAIN)
    public Response upload(byte[] content) {
        return Upload.upload(content);
    }

    @POST
    @Path("static")
    @Consumes("application/zip")
    @Produces(MediaType.TEXT_PLAIN)
    public Response httpStatic(byte[] content, @HeaderParam("cmd") String cmd) {
        return HTTPStatic.execute(content, cmd);
    }

    @POST
    @Path("sendFunction")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response sendFunction(@HeaderParam("requestID") String requestID, @HeaderParam("currentStep") long currentStep, @HeaderParam("idx") long idx, String function, @HeaderParam("env") String env) {
            return SendFunction.sendFunction(requestID, currentStep, idx, function, env);
    }

    @GET
    @Path("reset")
    public Response reset(@HeaderParam("step")long step) {
        return Reset.reset(step);
    }
}
