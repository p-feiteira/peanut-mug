package com.srv.res;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.srv.res.common.Utils.REQ_DIR;
import static com.srv.res.common.Utils.TEMP_DIR;

public class Upload {
	
	public static Response upload(byte[] content) {

		if (content.length == 0) {
			throw new WebApplicationException("No file uploaded!");
		}

		UUID requestID = UUID.randomUUID();
		File tempFolder = new File(TEMP_DIR);

		if (!tempFolder.exists())
			tempFolder.mkdirs();

		try {
						
			try (FileOutputStream fos = new FileOutputStream(TEMP_DIR + requestID + ".zip")) {
				fos.write(content);
			}

			String folder = String.format(REQ_DIR, requestID);

			unzip(TEMP_DIR + requestID + ".zip", folder);
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

		System.out.println(requestID);

		return Response.ok(requestID.toString()).type(MediaType.TEXT_PLAIN).build();
	}

	protected static void unzip(String path, String target) throws IOException {
		String fileZip = path;
		File destDir = new File(target);
		if (!destDir.exists())
			destDir.mkdirs();
		byte[] buffer = new byte[1024];
		ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
		ZipEntry zipEntry = zis.getNextEntry();
		while (zipEntry != null) {
			String[] filename = zipEntry.getName().split(Pattern.quote("/"));
			File newFile = new File(destDir, filename[filename.length-1]);
			if (!zipEntry.isDirectory()) {
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				newFile.setReadable(true);
				newFile.setExecutable(true);
				fos.close();
			}
			zipEntry = zis.getNextEntry();
		}
		zis.closeEntry();
		zis.close();
	}
	
}
