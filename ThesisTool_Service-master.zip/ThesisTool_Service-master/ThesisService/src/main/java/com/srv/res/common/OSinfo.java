package com.srv.res.common;

public class OSinfo {

    Pair<String, String> shell;
    String filename;
    String command[];

    public OSinfo(Pair<String, String> shell, String filename, String[] command){
        this.shell = shell;
        this.filename = filename;
        this.command = command;
    }

    public OSinfo(Pair<String, String> shell, String[] command){
        this.shell = shell;
        this.filename = null;
        this.command = command;
    }

    public String[] getCommand() {
        return command;
    }

    public String getFilename() {
        return filename;
    }

    public Pair<String, String> getShell() {
        return shell;
    }

}
