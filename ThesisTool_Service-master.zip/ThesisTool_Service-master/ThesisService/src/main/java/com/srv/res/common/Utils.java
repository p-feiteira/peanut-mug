package com.srv.res.common;

import java.io.*;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;

public class Utils {

    public static final String TEMP_DIR = System.getProperty("user.dir") + File.separator + "temp" + File.separator;
    public static final String REQ_DIR = TEMP_DIR + "%s";
    public static final String BASE_DIR = System.getProperty("user.dir") + File.separator;
    private static String digits = "0123456789abcdef";

    public static Properties loadConfig(String path) {
        Properties properties = new Properties();
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(path);
            properties.load(inputStream);
        } catch (IOException e) {
        	 System.err.println("Configuration file not found!");
             System.exit(1);
        }finally{
            if(inputStream != null){
                try{
                    inputStream.close();
                }catch(IOException e){
                    System.err.println(e.getMessage());
                    System.exit(1);
                }
            }
        }
        return properties;
    }

    public static Properties loadConfig(File f) {
        Properties properties = new Properties();
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(f);
            properties.load(inputStream);
        } catch (IOException e) {
        	System.err.println("Configuration file not found!");
            System.exit(1);
        }finally{
            if(inputStream != null){
                try{
                    inputStream.close();
                }catch(IOException e){
                    System.err.println(e.getMessage());
                    System.exit(1);
                }
            }
        }
        return properties;
    }

    public static File getFile(String path, String extension) {
        File f = new File(path);
        File[] matchingFiles = f.listFiles((dir, name) -> name.endsWith(extension));
        return matchingFiles[0];
    }

    public static Pair<Boolean, Pair<String, String>> getShell() {
        boolean isWindows = System.getProperty("os.name")
                .toLowerCase().startsWith("windows");
        if (isWindows) {
            return new Pair<Boolean, Pair<String, String>>(true, new Pair<String, String>("cmd.exe", "/c"));
        } else {
            return new Pair<Boolean, Pair<String, String>>(false, new Pair<String, String>("sh", "-c"));
        }
    }

    public static OSinfo getInfo(Properties props, String folder, String filename, String line, boolean isStatic) {

        //result[0] -> shell
        //result[1] -> startComm
        String command[];

        String env = props.getProperty("environment");

        String cmd = "";

        if (isStatic) {
            cmd = line;
        } else {
            cmd = "\"addpath(\'" + folder + "\');" + line + "\"";
        }
       
        Pair<Boolean, Pair<String, String>> pair = getShell();

        boolean isWindows = pair.getKey();
        Pair<String, String> comm = pair.getValue();

        //TODO
        if (isWindows) {
            if(!isStatic)
            command = new String[]{comm.getKey(), comm.getValue(), env, "--eval", cmd};
            else{
                command = new String[]{comm.getKey(), comm.getValue()};
                command = Utils.concatArrays(command, cmd.split("\\s+"));
            }
            
            

            return new OSinfo(comm, command);
        } else {
            String name;
            name = String.format("%s.sh", filename);
            command = new String[]{comm.getKey(), comm.getValue(), name};
            File f = new File(name);

            StringBuilder builder = new StringBuilder();
            if(!isStatic) {
                builder.append(env);
                builder.append(" --eval ");
            }
                builder.append(cmd);
               
            BufferedWriter writer = null;
            try {
                writer = new BufferedWriter(new FileWriter(f));
                writer.write(builder.toString());
                writer.close();
                f.setExecutable(true, true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return new OSinfo(comm, name, command);
        }

    }

    public static byte[] generateToken() {
        SecureRandom random = new SecureRandom();
        random.setSeed(System.currentTimeMillis());
        byte bytes[] = new byte[128];
        random.nextBytes(bytes);
        return bytes;
    }

    public static byte[] generateTTL() throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, 60);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String formatter = simpleDateFormat.format(calendar.getTime());
        return formatter.getBytes();
    }

    public static String toHex(byte[] data, int length) {
        StringBuffer buf = new StringBuffer();

        for (int i = 0; i != length; i++) {
            int v = data[i] & 0xff;

            buf.append(digits.charAt(v >> 4));
            buf.append(digits.charAt(v & 0xf));
        }

        return buf.toString();
    }

    public static String[] concatArrays(String[]... arrays) {
        List<String> result = new ArrayList<>();

        for (String[] current : arrays) {
            for (String ele : current) {
                result.add(ele);
            }
        }
        String[] resArr = new String[result.size()];

        return result.toArray(resArr);
    }

    public static String[] prepareExecution(String env, String folder, String line){
        String command[];

        boolean isWindows = System.getProperty("os.name")
                .toLowerCase().startsWith("windows");

        if (isWindows) {
            command = new String[]{"cmd.exe", "/c", env, "--eval", "\"addpath(\'" + folder + "\');" + line + "\""};
        } else {
            command = new String[]{"/bin/bash","-c", env + " --eval \"addpath(\'" + folder + "\');" + line + "\""};
        }

        return command;
    }
    
    public static String[] processCommand(String cmd) {
        String command[];
        
        boolean isWindows = System.getProperty("os.name")
                .toLowerCase().startsWith("windows");

        if (isWindows) {
            String[] splitCmd = cmd.split("\\s+");
            command = new String[]{"cmd.exe", "/c"};
            command = concatArrays(command, splitCmd);
        } else {
            command = new String[]{"/bin/bash","-c", cmd};
        }

        return command;

    }
}
