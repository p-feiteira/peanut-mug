package com.srv.res;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import com.srv.res.common.ProcessStructure;
import jakarta.ws.rs.core.Response;

public class Config {
	
	public static Response config(int threads, String ip, int port) {
				
		int value;

		if (threads > 0 && threads <= Runtime.getRuntime().availableProcessors()) {
			value = threads;
		} else {
			value = Runtime.getRuntime().availableProcessors();
		}
	
	    ProcessStructure.getInstance(value, ip, 9999);
	    	    
		saveThreadConfig(value);

		return Response.ok().build();
	}

	private static void saveThreadConfig(int threads) {
		try {

			FileOutputStream fos = new FileOutputStream("threads.tmp");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeInt(threads);
			oos.close();
			fos.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
	}

}
