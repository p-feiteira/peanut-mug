package com.srv.res.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class TCPClient {
	private Socket clientSocket;
	private PrintWriter out;

	public TCPClient(String ip, int port) {
		int counter = 0;
		while (counter <= 10) {
			try {
				clientSocket = new Socket(InetAddress.getByName(ip), port);
				clientSocket.setKeepAlive(true);
				clientSocket.setReuseAddress(true);
				out = new PrintWriter(clientSocket.getOutputStream(), true);
				System.out.println("TCP Client successfully binded to " + ip + " " + port);
				break;
			} catch (IOException e) {
				counter++;
				System.out.println("Create Client Error -> " + e.getMessage() + " " + counter + " try");
				try {
					Thread.sleep(200);
				} catch (InterruptedException e1) {
				}
			}
		}
	}

	public void sendMessage(String msg) {
		try {
			out.println(msg);
			out.flush();
		} catch (Exception e) {
			System.out.println("Send Message Error -> " + e.getMessage());
		}
	}

	public void stopConnection() {
		try {
			out.close();
			clientSocket.close();
		} catch (IOException e) {
			System.out.println("Stop Client Error -> " + e.getMessage());
		}
	}
}