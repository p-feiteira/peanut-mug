package com.srv.res;

import com.srv.res.common.ProcessStructure;
import com.srv.res.common.Utils;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

import java.io.File;
import java.util.Properties;

import static com.srv.res.common.Utils.getFile;

public class SendFunction {

	private final static ProcessStructure instance = ProcessStructure.getInstance(-1, null, -1);

	public static Response sendFunction(String requestID, long currentStep, long idx, String function, String env) {

		String folder;
		Properties properties;

		if (requestID != null) {
			folder = String.format(Utils.REQ_DIR, requestID);
			properties = Utils.loadConfig(getFile(folder, "properties"));
			File dir = new File(folder);

			if (!dir.exists())
				throw new WebApplicationException("Project with id: " + requestID + " does not exist in the system");

		} else {
			requestID = "default";
			folder = String.format(Utils.REQ_DIR, requestID);
			properties = new Properties();
			properties.put("environment", env);
			File f = new File(folder);
			if (!f.exists())
				f.mkdirs();
		}

		instance.structure.newProcess(folder, requestID, currentStep, idx, false,
				Utils.prepareExecution(properties.getProperty("environment"), folder, function));

		return Response.ok().build();
	}

}
