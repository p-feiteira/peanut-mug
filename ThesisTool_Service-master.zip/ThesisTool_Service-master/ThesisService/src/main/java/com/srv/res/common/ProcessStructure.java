package com.srv.res.common;

import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

import com.google.gson.Gson;

public final class ProcessStructure {

	private static volatile ProcessStructure instance;

	public ProcessStructureClass structure;

	private ProcessStructure(int threads, TCPClient client) {
		this.structure = new ProcessStructureClass(threads, client);
	}

	public static ProcessStructure getInstance(int threads, String ip, int port) {
		ProcessStructure result = instance;
		if (result != null) {
			return result;
		}
		synchronized (ProcessStructure.class) {
			if (instance == null) {
				TCPClient client = new TCPClient(ip, 9999);
				instance = new ProcessStructure(threads, client);
				System.out.println("Instance started with " + threads + " threads");
			}
		}
		return instance;
	}

	public static class ProcessStructureClass {
		private ExecutorService executor;
		private volatile AtomicLong step;
		private TCPClient socketClient;

		public ProcessStructureClass(int threads, TCPClient client) {
			threadConfig(threads);
			this.step = new AtomicLong(0L);
			this.socketClient = client;
		}

		public void newProcess(String directory, String requestID, long currentStep, long idx, boolean isSync,
				String... command) {

			executor.submit(() -> {
				if (currentStep < step.get()) {
					return;
				} else {
					try {
						Process process = Runtime.getRuntime().exec(command, null, new File(directory));
						process.onExit().whenComplete((p, e) -> {
							try {

								InputStream is = p.getInputStream();

								BufferedReader reader = new BufferedReader(new InputStreamReader(is));

								StringBuilder result = new StringBuilder();

								String line;
								while ((line = reader.readLine()) != null) {
									result.append(line);
								}
								result.append("\n");
								StructureEntry entry = new StructureEntry(currentStep, idx, requestID, process.pid(),
										result.toString());
								socketClient.sendMessage(new Gson().toJson(entry));
								System.out.println("New message sent!");
								reader.close();
								is.close();
							} catch (IOException exception) {
								System.out.println(e.getMessage());
							}
						});
						process.waitFor();
					} catch (IOException e) {
						System.out.println(e.getMessage());
					} catch (InterruptedException e1) {
						System.out.println(e1.getMessage());
					}

				}
			});

			System.out.println("Queue Size: " + ((ThreadPoolExecutor) executor).getQueue().size()
					+ " Largest Pool Size: " + ((ThreadPoolExecutor) executor).getLargestPoolSize()
					+ " Active Threads: " + ((ThreadPoolExecutor) executor).getActiveCount());

		}

		public void reset(long newStep) {
			System.out.println("New step: " + newStep);
			synchronized (this) {
				this.step.set(newStep);
				((ThreadPoolExecutor) this.executor).getQueue().clear();
			}

		}

		private void threadConfig(int threads) {
			if (threads == -1) {
				lastThreadConfig();
			} else {
				this.executor = Executors.newFixedThreadPool(threads);
			}
		}

		private void lastThreadConfig() {
			int threads = loadThreads();

			int available;
			if (threads > 0) {
				available = threads;
			} else {
				available = Runtime.getRuntime().availableProcessors();
			}
			this.executor = Executors.newFixedThreadPool(available);
		}

		private static int loadThreads() {
			try {
				FileInputStream fis = new FileInputStream("threads.tmp");
				ObjectInputStream ois = new ObjectInputStream(fis);
				Integer value = ois.readInt();
				ois.close();
				return value;
			} catch (FileNotFoundException e) {
				return -1;
			} catch (IOException e) {
				return -1;
			}
		}

	}

	protected static class StructureEntry {
		private long currentStep;
		private long idx;
		private String requestID;
		private long pid;
		private String result;

		public StructureEntry(long currentStep, long idx, String requestID, long pid, String result) {
			this.currentStep = currentStep;
			this.idx = idx;
			this.requestID = requestID;
			this.pid = pid;
			this.result = result;
		}

		public long getCurrentStep() {
			return currentStep;
		}

		public long getIdx() {
			return idx;
		}

		public String getRequestID() {
			return requestID;
		}

		public long getPid() {
			return pid;
		}

		public String getResult() {
			return result;
		}
	}

}
