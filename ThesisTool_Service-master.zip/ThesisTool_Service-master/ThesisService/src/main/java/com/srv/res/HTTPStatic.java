package com.srv.res;

import com.srv.res.common.JavaRunCommand;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.io.*;
import java.util.UUID;

import static com.srv.res.Upload.unzip;
import static com.srv.res.common.Utils.*;

public class HTTPStatic {

    public static Response execute(byte[] content, String cmd){
        if(content.length == 0){
            throw new WebApplicationException("No file uploaded!");
        }

        UUID requestID = UUID.randomUUID();
        File tempFolder = new File(TEMP_DIR);

        if (!tempFolder.exists())
            tempFolder.mkdirs();

        try {
            try (FileOutputStream fos = new FileOutputStream(TEMP_DIR + requestID + ".zip")) {
                fos.write(content);
            }

            String folder = String.format(REQ_DIR, requestID);

            unzip(TEMP_DIR + requestID + ".zip", folder);
            
            
            String result = JavaRunCommand.systemRun(folder, true, processCommand(cmd));

            return Response.ok(result).type(MediaType.TEXT_PLAIN).build();

        } catch (IOException e) {
            e.getMessage();
        }
        return null;
    }
}
